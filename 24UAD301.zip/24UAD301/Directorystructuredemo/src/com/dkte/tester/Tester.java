package com.dkte.tester;

import java.util.Scanner;

import com.dkte.service.EmployeeService;

public class Tester {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		Scanner sc=new Scanner(System.in);
		System.out.println("Enter  array size:");
		int size=sc.nextInt();
		EmployeeService es=new EmployeeService(size);
		es.aceept(sc);
	}

}

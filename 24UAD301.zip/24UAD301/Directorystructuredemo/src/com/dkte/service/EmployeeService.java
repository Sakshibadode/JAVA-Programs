package com.dkte.service;

import java.util.Scanner;

import com.dkte.entities.Employee;

public class EmployeeService {
	Employee emp;
	Employee arr[];
	public EmployeeService()
	{
	}	
	public EmployeeService(int size)
	{
		arr=new Employee[size];
	}
	public EmployeeService(Employee emp)
	{
		this.emp=emp;
	}
	public void aceept(Scanner sc)
	{
		System.out.println("Enter id,name");
		emp=new Employee(sc.nextInt(),sc.next());
		
	}
	
}

package com.dkte;

public class demoStatic {
	 int num1;
	static int num2=200;
	
	
	static {
		System.out.println("static block");
		num2=20;
	}
	public demoStatic()
	{
		num1=10;
	}
	public demoStatic(int num1)
	{
		this.num1=num1;
	}
	
	public  int getNum1() {
		return num1;
	}
	public static int getNum2() {
		return num2;
	}
	void display()
	{
		System.out.println("num1-"+num1);
	}

}

package com.dkte;
import java.util.*;

public class demo {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		System.out.println("num2="+demoStatic.num2);
		System.out.println("num2="+demoStatic.getNum2());
		demoStatic e1=new demoStatic(100);
		demoStatic e2=new demoStatic(200);
		System.out.println("e2.num2 - " + e2.getNum2());
		e1.display();
		
		
		

	}

}

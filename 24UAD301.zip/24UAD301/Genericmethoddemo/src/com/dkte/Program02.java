package com.dkte;
class Box1<T> {
	// private T obj = new T(); // NOT OK
	// private static T obj;// NOT OK
	private T obj;
	public Box1(T obj)
	{
		this.obj=obj;
	}

	public void setObj(T obj) {
		this.obj = obj;
	}

	public T getObj() {
		return obj;
	}
}

public class Program02 {

	public static void main(String[] args) {
//		Box1<int> b1 = new Box1<int>(); // NOT OK
		Box1<Integer> b1=new Box1<>(10);
		System.out.println("value:="+b1.getObj());
		
	}

}


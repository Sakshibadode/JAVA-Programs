package com.dkte;

public class Program {
	
	public static <T> void displayArr(T[] arr)                   //Generic Method
	{
		System.out.println("*********************************");
		for(T element:arr)
			System.out.println("value:="+element);
	}

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		Integer i1[]= {10,20,30,40,50};
		displayArr(i1);
		
		String s1[]= {"sita","gita","nita"};
		displayArr(s1);
		
		Double d1[]= {10.0,20.0,30.0,40.0,50.0};
		displayArr(d1);
	}

}

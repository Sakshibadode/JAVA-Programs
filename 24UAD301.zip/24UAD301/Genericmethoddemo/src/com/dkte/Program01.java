package com.dkte;
class Box<T> {
		private T obj;

		public Box(T obj) {
			// TODO Auto-generated constructor stub
			this.obj=obj;
		}

		public void setObj(T obj) {
			this.obj = obj;
		}

		public T getObj() {
			return obj;
		}
}

class BoxObject {
	Object obj;
}

class BoxString {
	String obj;
}

public class Program01 {
	
	public static void main(String[] args) {
		
				Box<Integer> b1 = new Box<Integer>(10);

				Box<Integer> b2 = new Box<>(2);

				Box<Integer> b3 = new Box(4);

				Box b4 = new Box(3);

//				Box<Object> b = new Box<String>(); // NOT OK
				Box<?> b = new Box<String>("Sakshi"); // OK
				
				System.out.println("value:"+b1.getObj());
				System.out.println("value:"+b2.getObj());
				System.out.println("value:"+b3.getObj());
				System.out.println("value:"+b4.getObj());
				System.out.println("value:"+b.getObj());
				
			}

		

	}



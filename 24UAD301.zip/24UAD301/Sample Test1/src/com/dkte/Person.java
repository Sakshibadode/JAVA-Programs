package com.dkte;

import java.util.Scanner;

public class Person {
	String name;
	MyDate dateofbirth;
	
	public Person()
	{
		dateofbirth=new MyDate();
	}
	public Person(String name,int day,int month,int year)
	{
		this.name=name;
		this.dateofbirth=new MyDate(day,month,year);
	}
	public String getName() {
		return name;
	}
	public void setName(String name) {
		this.name = name;
	}
	public MyDate getDateofbirth() {
		return dateofbirth;
	}
	public void setDateofbirth(MyDate dateofbirth) {
		this.dateofbirth = dateofbirth;
	}
	public void accept1(Scanner sc)
	{
		
		System.out.println("Enter Name:");
		name=sc.next();
		System.out.println("Enter date of birth:=");
		dateofbirth=new MyDate();
		dateofbirth.accept(sc);
		
	}
	@Override
	public String toString()
	{
		dateofbirth.toString();
		return "[name="+name+",dateofbirth="+dateofbirth+"]";
		
	}
	public void display1()
	{
		System.out.println("name:="+name);
		System.out.println("date of birth:="+dateofbirth.toString());
		
	}
	

}

package com.dkte;

import java.util.Scanner;

public class Tester {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		Scanner sc=new Scanner(System.in);
		Employee[] e=new Employee[5];
		int index=0;
		int choice = 0;
		do
		{
			System.out.println("1.Add Employee");
			System.out.println("2.Display Employee");
			System.out.println("3.Search Emploee ID");
			System.out.println("4. Display Employees joined in given Year");
			System.out.println("5.Find Employee with Maximum Salary");
			System.out.println("6.Find Employee with Minimum Salary");
			System.out.println("7.Exit");
			System.out.println("Enter your choice:==");
			choice=sc.nextInt();
			switch(choice)
			{
			case 1:
				if(index<5)
				{
					e[index]=new Employee();
					e[index].accept2(sc);
					index++;
				}
				else
				{
					System.out.println("No vacancy available");
				}
				break;
				
			case 2:
				for(Employee emp:e)
					if(emp!=null)
						emp.display2();
				break;
			case 3:
				System.out.println("Enter Id to search:=");
				int empid=sc.nextInt();
				boolean found = false;
				for (Employee emp : e) {
				    if (emp != null && emp.getId() == empid) {
				        System.out.println("Employee found: " + emp);
				        found = true;
				       
				    }
				}
				if (!found) {
				    System.out.println("Employee not found.");
				}
				break;
			case 4:
				System.out.print("Enter the joining year: ");
				int yr = sc.nextInt();
				boolean foundYear = false;
				for (Employee emp : e) {
				    if (emp != null && emp.getDateOfJoining().getYear()==yr)
				    {
				        System.out.println(emp);
				        foundYear = true;
				    }
				}
				if (!foundYear) {
				    System.out.println("No employees joined in year " + yr);
				}
				break;
			case 5:
				Employee maxEmp = null;
				for (Employee emp : e) {   
				    if (emp != null) {
				        if (maxEmp == null || emp.getSalary() > maxEmp.getSalary()) {
				            maxEmp = emp;
				        }
				    }
				}
				if (maxEmp != null)
				    System.out.println("Employee with max salary: " + maxEmp);
				else
				    System.out.println("No employees found.");
				break;
			case 6:
				Employee minEmp=null;
				for(Employee emp:e)
					if(emp!=null)
						if(minEmp==null || emp.getSalary()<minEmp.getSalary())
							minEmp=emp;
				if(minEmp!=null)
					System.out.println("Employee with min salary:"+minEmp);
				else
					System.out.println("no employee found");
				break;
			case 7:
				System.out.println("Exiting!!!!!");
				break;
			default:
				System.out.println("Invalid choice!!!");
				break;
				
			}
		}while(choice!=7);
		

	}

}

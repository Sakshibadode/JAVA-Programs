package com.dkte;

import java.util.Scanner;

public class Employee extends Person{
	int id;
	String department;
	double salary; 
	MyDate dateOfJoining;
	
	
	public Employee()
	{
		dateOfJoining=new MyDate();
		
	}
	public Employee(int id,String department,double salary,int day,int month,int year)
	{
		this.id=id;
		this.department=department;
		this.salary=salary;
		this.dateOfJoining=new MyDate(day,month,year);
	}
	public int getId() {
		return id;
	}
	public void setId(int id) {
		this.id = id;
	}
	public String getDepartment() {
		return department;
	}
	public void setDepartment(String department) {
		this.department = department;
	}
	public double getSalary() {
		return salary;
	}
	public void setSalary(double salary) {
		this.salary = salary;
	}
	public MyDate getDateOfJoining() {
		return dateOfJoining;
	}
	public void setDateOfJoining(MyDate dateOfJoining) {
		this.dateOfJoining = dateOfJoining;
	}
	public void accept2(Scanner sc)
	{
		
		System.out.println("Enter id:");
		id=sc.nextInt();
		System.out.println("Enter department:");
		department=sc.next();
		System.out.println("Enter salary:");
		salary=sc.nextDouble();
		System.out.println("Enter Date of joining:=");
		dateOfJoining.accept(sc);
		
		
	}
	@Override
	public String toString()
	{
		dateOfJoining=new MyDate();
		dateOfJoining.toString();
		return  "[id="+id+",departmant="+department+",salary="+salary+",dateOfJoining="+dateOfJoining+"]";
		
	}
	public void display2()
	{
		System.out.println("id:"+id);
		System.out.println("department:="+department);
		System.out.println("salary:="+salary);
		System.out.println("date of joining:="+dateOfJoining.toString());
		
		
	}

}

package com.dkte;

public class Program02 {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		StringBuffer s1=new StringBuffer("Sakshi");
		s1.append("Badode");
		
		StringBuilder s2=new StringBuilder("Sakshi");
		s2.append("Badode");
		
		System.out.println("s1"+s1);
		System.out.println("s2"+s2);

	}

}

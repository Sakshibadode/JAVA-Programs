package com.dkte;

import java.util.StringTokenizer;

public class Program03 {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		String s="Sakshi Badode";
		System.out.println("Original String:"+s);
		StringTokenizer st=new StringTokenizer(s);
		while(st.hasMoreTokens())
			System.out.println(st.nextToken());
		

	}

}

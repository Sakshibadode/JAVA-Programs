package com.dkte;

public class Program01 {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		StringBuilder s1=new StringBuilder("Sakshi");
		StringBuilder s2=new StringBuilder("Sakshi");
		System.out.println("s1="+s1);
		System.out.println("s2="+s2);
		System.out.println("s1==s2"+(s1==s2));       //false
		System.out.println("s1 equals to s2:"+(s1.equals(s2)));
		

	}

}

package com.dkte;

import java.util.StringTokenizer;

public class Program04 {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		String s="www.sakshi/badode";
		System.out.println("String:="+s);
		StringTokenizer st=new StringTokenizer(s,"./",true);
		while(st.hasMoreTokens())
			System.out.println(st.nextToken());

	}

}

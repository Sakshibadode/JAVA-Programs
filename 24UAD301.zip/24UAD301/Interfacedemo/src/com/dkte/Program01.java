package com.dkte;

import java.util.Scanner;

public class Program01 {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		Scanner sc=new Scanner(System.in);
		Acceptable a1;
		a1=new Time();
		//a1=new Date();
		//a1=new Employee();
		a1.accept(sc);
		Time t1=(Time) a1;
		t1.display();
		//Employee e=(Employee) a1;
		//e.display();
		//Date d=(Date) a1;
		//d.display();
		
	}

}

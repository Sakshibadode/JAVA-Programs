package com.dkte;

import java.util.Scanner;

interface Acceptable
{
	void accept(Scanner sc);
}
interface Displayble
{
	void display();
}
class Time implements Acceptable,Displayble
{
	int hr;
	int min;

	@Override
	public void accept(Scanner sc) {
		// TODO Auto-generated method stub
		System.out.println("Enter hrs:");
		hr=sc.nextInt();
		System.out.println("Enter min:");
		min=sc.nextInt();
	}

	@Override
	public void display() {
		// TODO Auto-generated method stub
		System.out.println("hrs:min"+hr+":"+min);
	}
	
}
class Date implements Acceptable,Displayble
{
	int day;
	int month;
	int year;
	@Override
	public void accept(Scanner sc) {
		// TODO Auto-generated method stub
		System.out.println("Enter day:");
		day=sc.nextInt();
		System.out.println("Enter month:");
		month=sc.nextInt();
		System.out.println("Enter year:");
		year=sc.nextInt();
	}
	@Override
	public void display() {
		// TODO Auto-generated method stub
		System.out.println("Date details::="+day+"/"+month+"/"+year);
	}
	
}
class Employee implements Acceptable,Displayble
{
	int empid;
	String name;
	double salary;
	
	@Override
	public void accept(Scanner sc) {
		// TODO Auto-generated method stub
		System.out.println("Enter empid:");
		empid=sc.nextInt();
		System.out.println("Enter name:");
		name=sc.next();
		System.out.println("Enter salary:");
		salary=sc.nextDouble();
	}
	@Override
	public void display() {
		// TODO Auto-generated method stub
		System.out.println("Employee Details::="+empid+","+name+","+salary);
	}

	
}

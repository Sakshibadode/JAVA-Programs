package com.dkte;

public @interface override {

}

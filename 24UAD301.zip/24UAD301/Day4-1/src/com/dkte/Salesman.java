package com.dkte;

import java.util.Scanner;

public class Salesman extends Employee {
	int commission;
	
	public Salesman()
	{
		
	}
	public Salesman(String name,int empid,double salary,double bonus,int commission)
	{	
	    
		this.commission=commission;
		
	}
	@override
	public void accept(Scanner sc)
	{
		super.accept(sc);
		System.out.println("Enter commission:");
		commission=sc.nextInt();
	}
	@override
	public void display()
	{
		super.display();
		System.out.println("commission:="+commission);
	}

}

package com.dkte;

import java.util.Scanner;

public class Employee {
	String name;
	int empid;
	double salary;
	
	public Employee()
	{
		
	}
	public Employee(String name,int empid,double salary)
	{
		this.name=name;
		this.empid=empid;
		this.salary=salary;
	}
	public void accept(Scanner sc)
	{
		System.out.println("Enter the name:=");
		name=sc.next();
		System.out.println("Enter the ID:=");
		empid=sc.nextInt();
		System.out.println("Enter the salary:=");
		salary=sc.nextDouble();
	}
	public void display()
	{
		System.out.println("Name:="+name);
		System.out.println("Id:="+empid);
		System.out.println("salary:="+salary);
		
	}

}

package com.dkte;


import java.util.Scanner;

public class Manager extends Employee {
	double bonus;
	
	public Manager() {
		
	}
	public Manager(double bonus,String name,int empid,double salary)
	{
		this.bonus=bonus;
		
	}
	@override
	
	public void accept(Scanner sc)
	{
		super.accept(sc);
		System.out.println("Enter bonus");
		bonus=sc.nextDouble();
	}
	@override
	public void display()
	{
		super.display();
		System.out.println("Bonus:="+bonus);
	}
}

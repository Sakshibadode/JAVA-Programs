package com.dkte;

import java.util.Objects;

public class Date {
	int day;
	int month;
	int year;
	
	public Date()
	{
		
	}
	public Date(int day,int month,int year)
	{
		this.day=day;
		this.month=month;
		this.year=year;
	}
	@Override
	public String toString()
	{
		return  "Date[day="+day+",month="+month+",year="+year+"]";
		
	}
	@Override
	public int hashCode() {
		return Objects.hash(day, month, year);
	}
	@Override
	public boolean equals(Object obj) 
	{
		if (this == obj)
			return true;
		if (obj == null)
			return false;
		if(obj instanceof Date)
		{
			Date d3=(Date) obj;
			if(this.day==d3.day && this.month==d3.month&&this.year==d3.year)
				return true;
			
		}
		return false;
	}
}

package com.dkte;

public class Tester {
	
	public static void main1(String[] args) {
		// TODO Auto-generated method stub
		Date d1=new Date();
		System.out.println(d1.toString());
		Date d2=new Date(1,1,2001);
		System.out.println(d2);
		}
	
	
	public static void main(String[] args)
	{
		Date d1=new Date(1,1,2001);
		Date d2=new Date(1,1,2001);
		System.out.println("d1="+d1);
		System.out.println("d2="+d2);
		System.out.println("d1==d2"+(d1==d2));
		boolean a=d2.equals(d1);
		System.out.println(a);
		System.out.println("d1 equals d2"+(d2.equals(d1)));
	}
	
	

	

}

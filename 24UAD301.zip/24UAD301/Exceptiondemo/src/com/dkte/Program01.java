package com.dkte;

import java.util.InputMismatchException;
import java.util.Scanner;

public class Program01 {

	public static void main(String[] args) {
				// TODO Auto-generated method stub
			
				int a;
				int b;
				Scanner sc=new Scanner(System.in);
				try
				{
					System.out.println("Enter number a:");
					a=sc.nextInt();
					System.out.println("Enter number b:");
					b=sc.nextInt();
					int result=a/b;
					System.out.println("Result:="+result);
				}catch(ArithmeticException e)
				{
					System.out.println("Arithmetic Exception:Divide by zero!!!");
				}
				catch(InputMismatchException e)
				{
					System.out.println("InputMismatch Exception!!!");
				}
				System.out.println("program is finished!!!");

	}

}

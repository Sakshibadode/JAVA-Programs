package com.dkte;

public class Date 
{
	int day;
	int month;
	int year;
	public int getDay() {
		return day;
	}
	public void setDay(int day) {
		if(day<=0 || day>31)
			throw new RuntimeException();
		this.day = day;
	}
	public int getMonth() {
		return month;
	}
	public void setMonth(int month) throws Exception {
		if(month<=0 || month>12)
			throw new Exception("Day is only beteen 1 and 32");
		this.month = month;
	}
	public int getYear() {
		return year;
	}
	public void setYear(int year) {
		this.year = year;
	}
	@Override
	public String toString() {
		return "Date [day=" + day + ", month=" + month + ", year=" + year + "]";
	}
	
	
}


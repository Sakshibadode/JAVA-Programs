package com.dkte;

public class Program04 {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		try
		{
			Date d1=new Date();
			d1.setDay(32);
			d1.setMonth(11);
			d1.setYear(2001);
			System.out.println(d1);
		}
		catch(Exception e)
		{
			e.printStackTrace();
		}
	}

}

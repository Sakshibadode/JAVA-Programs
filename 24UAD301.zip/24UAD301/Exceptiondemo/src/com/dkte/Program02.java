package com.dkte;

import java.util.Scanner;

public class Program02 {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		int a;
		int b;
		Scanner sc=new Scanner(System.in);
		try
		{
			System.out.println("Enter number a:");
			a=sc.nextInt();
			System.out.println("Enter number b:");
			b=sc.nextInt();
			int result=a/b;
			System.out.println("Result:="+result);
		}catch(Exception e)                                                     //Generic catch
		{
			e.printStackTrace();
		}
		finally
		{
			System.out.println("Always executed!!!");
			sc.close();
		}
		System.out.println("program is finished!!!");

	}

}

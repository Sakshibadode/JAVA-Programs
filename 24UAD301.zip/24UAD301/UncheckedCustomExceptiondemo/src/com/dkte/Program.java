package com.dkte;

public class Program {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		try
		{
		Time t1=new Time();
		t1.setHr(1);
		t1.setMin(58);
		System.out.println(t1);
		}
		catch(RuntimeException e)
		{
			e.printStackTrace();
		}

	}

}

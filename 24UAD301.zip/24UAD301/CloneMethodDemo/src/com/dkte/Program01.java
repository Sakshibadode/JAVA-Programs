package com.dkte;

public class Program01 {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		try
		{
		Person p1=new Person("Sakshi","Nandre");
		Person p2=(Person) p1.clone();
		System.out.println("person details:"+p1);
		System.out.println("person details:"+p2);
		p2.name="shubham";
		System.out.println("After change::");
		System.out.println("person details:"+p1);
		System.out.println("person details:"+p2);
		}
		catch(CloneNotSupportedException e)
		{
			e.printStackTrace();
		}
	}

}

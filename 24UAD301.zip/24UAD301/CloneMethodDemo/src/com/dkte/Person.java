package com.dkte;

public class Person implements Cloneable{
	String name;
	String Address;
	
	public Person()
	{
		
	}
	public Person(String name, String address) {
		
		this.name = name;
		this.Address = address;
	}
	@Override
	public String toString() {
		return "Person [name=" + name + ", Address=" + Address + "]";
	}
	@Override
	protected Object clone() throws CloneNotSupportedException
	{
		return super.clone();
	}
}

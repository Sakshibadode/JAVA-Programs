package com.dkte;

public class Program01 {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		Test t=new Test();
		final int num1;
		num1=20;
		System.out.println(num1);
	}

}

package com.dkte;

public class Test {
	final int num1;
	
	public Test()
	{
		num1=10;
		System.out.println(num1);
	}

}

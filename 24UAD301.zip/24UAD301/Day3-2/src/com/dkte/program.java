package com.dkte;

import java.util.Scanner;

public class program {
	
	public static int menu(Scanner sc)
	{
		System.out.println("---------------");
		System.out.println("1.Add");
		System.out.println("2.Display");
		System.out.println("3.Find");
		System.out.println("4.Exit");
		System.out.println("Enter your choice:=");
		return sc.nextInt();
	}

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		Scanner sc=new Scanner(System.in);
		Student arr[]=new Student[5];
		int index=0;
		int choice;
		while((choice=menu(sc))!=0)
		{
			switch(choice)
			{
			case 1:
				if(index>5)
				{
					System.out.println("course is full!!");
				}
				else
				{
					arr[index]=new Student();
					arr[index].acceptstudent(sc);
					index++;
				}
				break;
			
			case 2:
				for(Student s:arr)
					if(arr!=null)
					{
						s.displayStud();
					}
				break;
				
			case 3:
				System.out.println("Enter roll no:==");
				int roll=sc.nextInt();
				boolean found=false;
				for(Student e:arr)
					if(e!=null && e.rollno==roll)
					{
						e.displayStud();
						System.out.println("Student found....");
						
					}
				if(!found)
				{
					System.out.println("Student not found...");
				}
				break;
			case 4:
				System.out.println("Exiting!!!");
				break;
			default:
				System.out.println("Invalis choice");
				break;
				
			}
		}
	}

}

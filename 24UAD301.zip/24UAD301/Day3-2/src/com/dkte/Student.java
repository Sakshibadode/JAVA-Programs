package com.dkte;
import java.lang.*;
import java.util.Scanner;

public class Student {
	String name;
    int rollno;
	double marks;
	Scanner sc=new Scanner(System.in);
	public Student()
	{
		
	}
	
	public Student(String name,int rollno,double marks)
	{
		this.name=name;
		this.rollno=rollno;
		this.marks=marks;
	}
	public void acceptstudent(Scanner sc)
	{
		System.out.println("Enter name:");
		this.name=sc.next();
		System.out.println("Enter rollno:");
		this.rollno=sc.nextInt();
		System.out.println("Enter marks:");
		this.marks=sc.nextDouble();
	}
	
	public void displayStud()
	{
		System.out.println("Student info!!!!!");
		System.out.println("name:="+name);
		System.out.println("rollno:="+rollno);
		System.out.println("marks:="+marks);
		
	}

}

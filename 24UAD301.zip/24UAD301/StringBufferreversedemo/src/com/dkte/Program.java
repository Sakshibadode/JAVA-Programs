package com.dkte;

public class Program {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		String s="Sakshi";
		StringBuilder s1=new StringBuilder(s);
		StringBuilder s2=s1.reverse();
		System.out.println("Reverse String:="+s2);
				

	}

}

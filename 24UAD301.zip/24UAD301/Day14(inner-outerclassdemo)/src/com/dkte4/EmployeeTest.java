package com.dkte4;

import java.util.ArrayList;
import java.util.Collections;
import java.util.List;
import java.util.Scanner;

public class EmployeeTest {
	public static int menu(Scanner sc)
	{
		System.out.println("0.Exit");
		System.out.println("1.Diaplay all Employees");
		System.out.println("2.display employees on empid");
		System.out.println("3.display employees on name");
		System.out.println("4.display employees on salary");
		System.out.println("5.display employee in descending order");
		System.out.println("Enter your choice:=");
		return sc.nextInt();
	}

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		Scanner sc=new Scanner(System.in);
		List<Employee> elist=new ArrayList<>();
		elist.add(new Employee(101,"sakshi",20000));
		elist.add(new Employee(105,"sita",50000));
		elist.add(new Employee(102,"gita",10000));
		elist.add(new Employee(104,"nita",70000));
		elist.add(new Employee(103,"rita",60000));
		System.out.println("Size:="+elist.size());
		int choice;
		while((choice=menu(sc))!=0)
		{
			switch(choice)
			{
			case 1:
				elist.forEach(e->System.out.println(e));
				break;
				
			case 2:
				Collections.sort(elist);
				elist.forEach(e->System.out.println(e));
				break;
				
			case 3:
				elist.sort((e1,e2)->e1.getName().compareTo(e2.getName()));
				elist.forEach(e->System.out.println(e));
				break;
			case 4:
				elist.sort((e1,e2)->Double.compare(e1.getSalary(), e2.getSalary()));
				elist.forEach(e->System.out.println(e));
				break;
			case 5:
				elist.sort((e1,e2)->Double.compare(e2.getSalary(), e1.getSalary()));
				elist.forEach(e->System.out.println(e));
				break;
			default:
				System.out.println("Invalid choice!!!");
				break;
			}
		}	

	}

}

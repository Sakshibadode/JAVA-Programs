package com.dkte3;

import java.util.Arrays;
import java.util.Comparator;

public class Program04 {

	public static void main(String[] args) {
		
		class ArrComparator implements Comparator<Integer>			
		{

			@Override
			public int compare(Integer o1, Integer o2) {
				// TODO Auto-generated method stub
				return o2-o1;
			}
			
		}
		ArrComparator arrcomparator=new ArrComparator();
		
		Integer[] arr= {10,30,60,80,50};
		System.out.println("Before Sorting->"+Arrays.toString(arr));
		Arrays.sort(arr,arrcomparator);
		System.out.println("After Sorting->"+Arrays.toString(arr));
		

	}

}

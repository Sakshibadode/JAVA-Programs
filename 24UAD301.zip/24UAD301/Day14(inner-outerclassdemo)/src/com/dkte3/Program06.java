package com.dkte3;

import java.util.Arrays;

public class Program06 {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		
		Integer[] i= {20,50,60,10,80};
		System.out.println("Before Sorting->"+Arrays.toString(i));
		Arrays.sort(i,(Integer i1,Integer i2)->           // short-hand implementation of functional interface  // lambda expression // `->` : lambda operator
		{
			return i1-i2;
		});
		
		System.out.println("After Sorting->"+Arrays.toString(i));
	}

}

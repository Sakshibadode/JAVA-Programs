package com.dkte3;

import java.util.Arrays;

public class Program07 {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		Integer[] i1= {20,50,80,10,30};
		System.out.println("Before Sorting->"+Arrays.toString(i1));
		Arrays.sort(i1,(o1,o2)->o1-o2);     // short-hand implementation of functional interface  // lambda expression  // `->` : lambda operator
		System.out.println("After Sorting->"+Arrays.toString(i1));
		
	}

}

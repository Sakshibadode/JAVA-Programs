package com.dkte3;

import java.util.Arrays;
import java.util.Comparator;

public class Program05 {

	public static void main(String[] args) {
		
		Integer[] arr= {90,40,10,30,20};
		System.out.println("Before Sorting->"+Arrays.toString(arr));
		
		Arrays.sort(arr,new Comparator<Integer>()       	// Anonymous Object of anonymous Inner class
		{

			@Override
			public int compare(Integer o1, Integer o2) {
				// TODO Auto-generated method stub
				return o1-o2;
			}
			
		});
		System.out.println("After Sorting->"+Arrays.toString(arr));
		

	}

}

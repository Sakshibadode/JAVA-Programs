package com.dkte3;

import java.util.function.BinaryOperator;

public class Program08 {
	
	public static void doWork(Integer i1,Integer i2,BinaryOperator<Integer> i)  // sort(arr,Comparator<T> c)
	{
		System.out.println("Result"+i.apply(i1, i2));
	}

	public static void main(String[] args) {
		
		// non capturing lambda
		doWork(10,20,(i1,i2)->i1+i2);
		doWork(20,10,(i1,i2)->i1-i2);
		doWork(20,2,(i1,i2)->i1*i2);
		doWork(10,5,(i1,i2)->i1/i2);
		
		
	}

}

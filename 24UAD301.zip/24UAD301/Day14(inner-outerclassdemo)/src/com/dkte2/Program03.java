package com.dkte2;
public class Program03 {
	
	int field1;
	static int field2;
	
	public void method1()
	{
		int localfield=5;
		
		class local
		{
			int field3;
			//static int field4;  //Doesn't allow to write or access inner class static field  inside non-static method or inner class
			
			void m1()
			{
				System.out.println(field1);
				System.out.println(field2);
				System.out.println(field3);
				System.out.println(localfield);
			//System.out.println(field4);
			}
		}
	}
	public static void method2()
	{
		int localfield=10;
		class local
		{
			int field5;
			//static int field6;
			
			/*static void m3()     //static methods are not allowed inside the local class
			{
				
			}
			*/
			
			void m2()
			{
				//System.out.println(field1);//access only static fields of outer class
				System.out.println(field2);
				System.out.println(field5);
				System.out.println(localfield);
				//System.out.println(field6);  //Doesn't allow to write or access inner class static field  inside non-static method or inner class
			}
		}
	}
	

	public static void main(String[] args) {
		

	}

}

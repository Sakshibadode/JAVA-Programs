package com.dkte;

class Outer
{
	int field1;
	static int field2;
	
	class Inner
	{
		int field3;
		//static int field4;  //Doesn't allow to write or access inner class static field  inside non-static method or inner class
		
	   void m1()
		{
			System.out.println(field1);
			System.out.println(field2);
			System.out.println(field3);
			
			
		}
	}
}

public class Program01 {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		Outer out=new Outer();
		Outer.Inner in=out.new Inner();
		in.m1();

	}

}

package com.dkte1;

class Outer
{
	int field1;
	static int field2;
	
	static class Inner
	{
		int field3;
		static int field4;  
		
	   void m1()
		{   //access only static fields of outer class and static nad non-static fields of inner class
			System.out.println(field2);
			System.out.println(field3);
			System.out.println(field4);	
		}
	   static void m2()
	   {
		  //access only static fields of inner and outer class
		   System.out.println(field2);
		   System.out.println(field4);
	   }
	}
}

public class Program02 {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
	
		Outer.Inner in=new Outer.Inner();
		in.m1();
		in.m2();
	}

}


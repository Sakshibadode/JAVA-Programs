 package com.dke1;

import java.util.Scanner;
import java.lang.*; 

public class MyInteger {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		Scanner sc=new Scanner(System.in);
		System.out.println("Enter a Number:=");
		int num=sc.nextInt();
		System.out.println("Binary Eqvivalant:"+Integer.toBinaryString(num));
		System.out.println("Octal Eqvivalant:"+Integer.toOctalString(num));
		System.out.println("hexadecimal Eqvivalant:"+Integer.toHexString(num));
		 
		
		
	}

}

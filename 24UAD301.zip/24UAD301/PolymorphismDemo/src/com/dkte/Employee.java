package com.dkte;

import java.util.Scanner;

public class Employee {
	int empid;
	double salary;
	
	public Employee()
	{
		
	}
	public Employee(int empid,double salary)
	{
		this.empid=empid;
		this.salary=salary;
	}
	public void accept(Scanner sc)
	{
		System.out.println("Enter emp ID:=");
		empid=sc.nextInt();
		System.out.println("Enter salary:=");
		salary=sc.nextDouble();
		
	}
	public void display()
	{
		System.out.println("Empoyee Id:"+empid);
		System.out.println("Employee salary:"+salary);
	}
}

package com.dkte;

import java.util.Scanner;

public class Salesman extends Employee {
	int no_of_products;
	int commission;
	
	public Salesman()
	{
		
	}
	public Salesman(int empid,double salary,int no_of_products,int commission)
	{
		super(empid,salary);
		this.no_of_products=no_of_products;
		this.commission=commission;
	}
	@Override
	public void accept(Scanner sc)
	{
		super.accept(sc);
		System.out.println("Enter no_of_products:");
		no_of_products=sc.nextInt();
		System.out.println("Enter commission:");
		commission=sc.nextInt();		
	}
	public void calculate_totalcommission()
	{
		System.out.println("Total Commission:="+(no_of_products*commission));
	}
	@Override
	public void display()
	{
		super.display();
		System.out.println("no of products:="+no_of_products);
		System.out.println("commission:="+commission);
	}
}

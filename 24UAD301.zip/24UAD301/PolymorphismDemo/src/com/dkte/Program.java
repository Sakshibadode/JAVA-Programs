package com.dkte;

import java.util.Scanner;

public class Program {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		Scanner sc=new Scanner(System.in);
		Employee e=new Employee();
		Manager m=new Manager();
		Salesman sm=new Salesman();
		
		e.accept(sc);
		e.display();
	}

}


	
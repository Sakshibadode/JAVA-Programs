package com.dkte;

public class Program01 {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		String s1="Sakshi";
	//	String s2=s1;
		String s2=s1;
		String s3="Sakshi";
		System.out.println("s1="+s1);
		System.out.println("s2="+s2);
		System.out.println("s1==s2:"+(s1==s2));                              //checking refrence
		System.out.println("s1 equals to s2:="+s1.equals(s2));             //checking values
		

	}

}

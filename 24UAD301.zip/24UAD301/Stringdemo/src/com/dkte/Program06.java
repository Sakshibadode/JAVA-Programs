package com.dkte;

public class Program06 {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		String s1="Sakshi";
		String s2="SAKSHI";
		String s3=s1.toUpperCase();
		String s4=s3;
		System.out.println("s1:"+s1);
		System.out.println("s2:"+s2);
		System.out.println("s2==s3:"+(s2==s3));  //false
		System.out.println("s3==s4:"+(s3==s4));  //true
		System.out.println("s2 equals to s3:"+s2.equals(s3));
		

	}

}

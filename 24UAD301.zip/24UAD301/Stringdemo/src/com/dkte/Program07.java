package com.dkte;

public class Program07 {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		String s1="sakshi";
		s1.toUpperCase();
		System.out.println("s1="+s1); //immutable case once String is created it does change 
		
		
		String s2=s1.toUpperCase();
		System.out.println("s2="+s2);
		
	}

}

package com.dkte;

public class Program03 {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		String s1="Sakshi";
	//	String s2=s1+"Badode";
		String s2="sak";
		String s3=s2+"shi";
		System.out.println("s1="+s1);
		System.out.println("s2="+s2);
		System.out.println("s1==s3:"+s1==s3);//false
		System.out.println("s1 equals to s3:"+s1.equals(s3));//false//this is an not equal because on runtime value can store on different objects
	}

}

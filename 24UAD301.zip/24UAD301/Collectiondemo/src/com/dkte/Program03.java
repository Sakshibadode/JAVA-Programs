package com.dkte;

import java.util.ArrayList;
import java.util.Collection;
import java.util.Objects;

class Employee1{
	int empid;
	String name;
	double salary;
	
	public Employee1() {
	
		
	}
	
	public Employee1(int empid) {
		super();
		this.empid = empid;
	}

	public Employee1(int empid, String name, double salary) {
		
		this.empid = empid;
		this.name = name;
		this.salary = salary;
	}
	
	@Override
	public String toString() {
		return "Employee [empid=" + empid + ", name=" + name + ", salary=" + salary + "]";
	}


	@Override
	public boolean equals(Object obj) {
		if (this == obj)
			return true;
		if (obj == null)
			return false;
		if(obj instanceof Employee1)
		{
			Employee1 e1=(Employee1) obj;
			if(this.empid==e1.empid)
				return true;
		}
		return false;
	}
	
	
	
	
};

public class Program03 {

	public static void main(String[] args) {
		Collection<Employee1> emplist=new ArrayList<Employee1>();
		emplist.add(new Employee1(103,"sita",10000));
		emplist.add(new Employee1(101,"gita",2000));
		emplist.add(new Employee1(102,"nita",1000));
		
		emplist.remove(new Employee1(101));
		
	
		System.out.println("size:"+emplist.size());
		System.out.println("Employee contains:"+emplist.contains(new Employee1(102)));
		System.out.println("Using for each:");
		for(Employee1 emp:emplist)
			System.out.println("Employee:"+emp);
		
		
		

	}

}

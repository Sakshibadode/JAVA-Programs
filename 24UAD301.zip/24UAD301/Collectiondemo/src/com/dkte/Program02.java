package com.dkte;

import java.util.ArrayList;
import java.util.Collection;
import java.util.Iterator;
//import java.util.LinkedHashSet;
//import java.util.LinkedList;

public class Program02 {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		Collection<Integer> c1=new ArrayList<>();
		//Collection<Integer> c2=new LinkedList<>();
	//	Collection<Integer> c3=new LinkedHashSet<>();
		
		c1.add(10);
		c1.add(20);
		c1.add(30);
		c1.add(40);
		c1.add(50);
		
		c1.remove(40);
		c1.clear();
		c1.add(80);
		c1.add(90);
		
		
		
		System.out.println("Size of list:"+c1.size());
		System.out.println("Using for each:=");
		for(Integer i:c1)
			System.out.println("Elements:"+i);
		
		
		System.out.println("Using Iterator:");
		Iterator<Integer> itr=c1.iterator();
		while(itr.hasNext())
			System.out.println("iterator:"+itr.next());
		
		

	}

}

package com.dkte;

import java.util.Arrays;
import java.util.Comparator;
import java.util.Scanner;

class Employee implements Comparable<Employee>
{
	int empid;
	String name;
	double salary;
	
	public Employee() {
	
	}

	public Employee(int empid, String name, double salary) {
		
		this.empid = empid;
		this.name = name;
		this.salary = salary;
	}

	@Override
	public String toString() {
		return "Employee [empid=" + empid + ", name=" + name + ", salary=" + salary + "]";
	}

	@Override
	public int compareTo(Employee o) {
		// TODO Auto-generated method stub
		return this.empid-o.empid;
	}
	
	
	
	
}


public class Program01 {
	
	public static void display(Employee[] e)
	{
		for(Employee element:e)
			System.out.println("Employeee:="+element);
			
	}

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		Scanner sc=new Scanner(System.in);
		Employee[] e=new Employee[5];
		e[0]=new Employee(101,"sakshi",10000);
		e[1]=new Employee(104,"sita",50000);
		e[2]=new Employee(102,"gita",30000);
		e[3]=new Employee(103,"nita",40000);
		e[4]=new Employee(106,"anita",1000);
		
		System.out.println("Before Sorting:");
		display(e);
		
		System.out.println("1.sort and display Employee on empid");
		System.out.println("2.sort and display Employee on names");
		System.out.println("3.sort and display Employee on salary");
		System.out.println("Enter your choice:");
		int choice=sc.nextInt();
		
		class Employeenamecomparator implements Comparator<Employee>
		{

			@Override
			public int compare(Employee o1, Employee o2) {
				// TODO Auto-generated method stub
				return o1.name.compareTo(o2.name);
			}
			
		}
		Employeenamecomparator employeenamecomprator=new Employeenamecomparator();
		
		class Employeesalarycomparator implements Comparator<Employee>
		{

			@Override
			public int compare(Employee o1, Employee o2) {
				// TODO Auto-generated method stub
				return Double.compare(o1.salary,o2.salary);
			}
			
		}
		
		Employeesalarycomparator employeesalarycomparator=new Employeesalarycomparator();
		
		switch(choice)
		{
		case 1:
			Arrays.sort(e);
			display(e);
			break;
		case 2:
			Arrays.sort(e,employeenamecomprator);
			display(e);
			break;
		case 3:
			Arrays.sort(e,employeesalarycomparator);
			display(e);
			break;
		case 4:
			System.out.println("Exiting!!!!");
			break;
		default:
			System.out.println("Invalid choice!!");
			break;
		}
		
	}

}

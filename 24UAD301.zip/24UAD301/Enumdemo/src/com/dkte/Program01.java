package com.dkte;

import java.util.Scanner;

enum Arithmeticops{
		EXIT,ADD,SUBSTRACT,MULTIPLY,DIVISION,SQUARE,SQUAREROOT
}
	public class Program01 {
		public static Arithmeticops menu(Scanner sc)
		{
			Arithmeticops ao[]= Arithmeticops.values();
			for(Arithmeticops as:ao)
				System.out.println(as.ordinal()+"."+as.name());
			System.out.println("Enter your choice:");
			int choiceindex=sc.nextInt();
			if(choiceindex<0 || choiceindex>=ao.length)
			{
				System.out.println("invalid choice");
				return menu(sc);
			}
			return ao[choiceindex];
		}

		
	public static void main(String[] args) {
			// TODO Auto-generated method stub
			Scanner sc=new Scanner(System.in);
			Arithmeticops choice;
			do
			{
				choice=menu(sc);
			if(choice==Arithmeticops.EXIT)
			{
				System.out.println("Exiting!!!!");
				break;
			}
			System.out.println("Enter num1:");
			int num1=sc.nextInt();
			System.out.println("Enter num2:");
			int num2=sc.nextInt();
			
			switch(choice)
			{
			
			case ADD:
				System.out.println("Addition:="+(num1+num2));
				break;
			case SUBSTRACT:
				System.out.println("Substraction:="+(num1-num2));
				break;
			case MULTIPLY:
				System.out.println("Multiplication:="+(num1*num2));
				break;
			case DIVISION:
				System.out.println("Division:="+(num1/num2));
				break;
			case SQUARE:
				System.out.println("Square(num1)"+(num1*num1));
				System.out.println("Square(num2)"+(num2*num2));
				break;
			case SQUAREROOT:
				System.out.println("Squareroot(num1)"+Math.sqrt(num1));
				System.out.println("Squareroot(num2)"+Math.sqrt(num2));
				break;
			
			
			}
			System.out.println();
			}while(true);
			 
			sc.close();
		}

	}



//checked custom Exception
package com.dkte;
class InvalidDateException extends Exception
{
	public InvalidDateException()
	{
		
	}
	public InvalidDateException(String message)
	{
		super(message);
	}
}

public class Date {
	int day;
    int month;
	public void setDay(int day) throws InvalidDateException    {
		if(day<=0 || day>31)
			throw new InvalidDateException("Day is between only 1 & 31");
		this.day = day;
	}
	public void setMonth(int month) throws InvalidDateException  {
		if(month<=0 || month>12)
			throw new InvalidDateException();
		this.month = month;
	}
	@Override
	public String toString() {
		return "Date [day=" + day + ", month=" + month + "]";
	}
	
}



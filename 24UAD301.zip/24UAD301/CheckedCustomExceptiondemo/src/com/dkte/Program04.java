package com.dkte;

public class Program04 {
	

		public static void main(String[] args) {
			// TODO Auto-generated method stub
			try
			{
				Date d1=new Date();
				d1.setDay(1);
				d1.setMonth(12);
				System.out.println(d1);
			}
			catch(InvalidDateException e)
			{
				e.printStackTrace();
			}

		}

	}


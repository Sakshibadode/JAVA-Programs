package com.sakshi;
import java.lang.*;

public class InvoiceTest {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		Invoice in=new Invoice("101","btl",2,10.0);
		Invoice in1=new Invoice("102","pen",3,11.0);
		in.display();
		in1.display();
		
		
		
	}

}

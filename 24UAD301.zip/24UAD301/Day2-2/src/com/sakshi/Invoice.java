package com.sakshi;

public class Invoice {
	private String part_number;
	private String part_description;
	private int quantity;
	private double price;
	
	public Invoice()
	{
		
	}
	
	public Invoice(String part_number,String part_description,int quantity,double price )
	{
		if(quantity>=0 )
		{
			this.quantity=quantity;
		}
		else
		{
			this.quantity=0;
		}
		if(price>=0)
		{
			this.price=price;
		}
		else
		{
			this.price=0.0;
		}
		
	}

	public String getPart_number() {
		return part_number;
	}

	public void setPart_number(String part_number) {
		this.part_number = part_number;
	}

	public String getPart_description() {
		return part_description;
	}

	public void setPart_description(String part_description) {
		this.part_description = part_description;
	}

	public int getQuantity() {
		return quantity;
	}

	public void setQuantity(int quantity) {
		if (quantity < 0)
			return;
		this.quantity = quantity;
	}

	public double getPrice() {
		return price;
	}

	public void setPrice(double price) {
		if (price < 0.0)
			return;
		this.price = price;
	}
	public void display()
	{
		System.out.println("Invoice amount="+(quantity*price));
		
		
	}
	
}

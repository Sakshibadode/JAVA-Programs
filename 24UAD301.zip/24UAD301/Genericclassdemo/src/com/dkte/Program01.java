package com.dkte;

import java.sql.Date;

class Box {
	private Object obj;

	public void setObj(Object obj) {
		this.obj = obj;
	}

	public Object getObj() {
		return obj;
	}
}

public class Program01 {

	public static void main(String[] args) {
		Box b1 = new Box();
		b1.setObj(new Integer(10)); // upcasting
		Integer i1 = (Integer) b1.getObj();
		System.out.println("i1 - " + i1);

		Box b2 = new Box();
		b2.setObj("sunbeam");
		String s1 = (String) b2.getObj();
		System.out.println("s1 - " + s1);



		Box b4 = new Box();
		b4.setObj("12.24");
		Double n1 = (Double) b4.getObj(); // ClassCastException
		System.out.println("n1 - " + n1);
	}

}
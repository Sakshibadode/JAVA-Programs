package com.dkte;
class Box1<T>
{
	private T obj;

	public T getObj() {
		return obj;
	}

	public void setObj(T obj) {
		this.obj = obj;
	}
}

public class Program02 {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		Box1<Integer> b1=new Box1<Integer>();
		b1.setObj(new Integer(10));
		Integer i1=b1.getObj();
		System.out.println("Integer:"+i1);
		
		Box1<String> s=new Box1<String>();
		s.setObj(new String("Sakshi"));
		String s1=s.getObj();
		System.out.println("String:"+(s1));
		
		Box1<Double> d=new Box1<Double>();
		d.setObj(new Double(10.0));
		Double d1=d.getObj();
		System.out.println("Double:="+d1);
		
	}

}

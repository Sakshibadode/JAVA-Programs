package com.dkte;



public class Orange extends Fruit{
	public Orange()
	{
		
	}
	public Orange(String name,String color, double weight, boolean isFresh)
	{
		super(name,color,weight,isFresh);
	}
	
	public String taste()
	{
		return "sour";
	}
	

}

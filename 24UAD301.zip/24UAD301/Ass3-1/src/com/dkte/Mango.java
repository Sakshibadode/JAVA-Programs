package com.dkte;




public class Mango extends Fruit{
	public Mango()
	{
		
	}
	public Mango(String name,String color, double weight, boolean isFresh)
	{
		super(name,color,weight,isFresh);
		
	}
	
	public String taste()
	{
		return "sweet";
	}
	
	
	

}

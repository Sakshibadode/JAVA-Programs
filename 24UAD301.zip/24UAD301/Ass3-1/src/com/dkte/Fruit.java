/*Q1 Apply inheritance n polymorphism 
a) Arrange Fruit,Apple,Orange,Mango in inheritance hierarchy 
b) Properties (instance variables)  : color : String , weight : double , name:String, isFresh : boolean 
c) Add suitable constructors. 
d) Override  toString correctly to return state of all fruits (including : name ,color , weight ) 
e) Add a taste() method : public String taste() */

package com.dkte;

import java.util.Scanner;

public class Fruit {
	String color;
	double weight;
	String name;
	boolean isFresh;
	
	public Fruit()
	{
		
	}
	public Fruit(String name,String color, double weight, boolean isFresh) 
	{
		this.color = color;
		this.weight = weight;
		this.name = name;
		
	}
	@Override
	public String toString()
	{
		return  "Fruit[name="+name+",color="+color+",weight="+weight+"]";
		
	}
	
	public boolean isFresh() {
		return isFresh;
	}
	public void setFresh(boolean isFresh) {
		this.isFresh = isFresh;
	}
	public void accept(Scanner sc)
	{
		System.out.println("Enter name of fruit:");
		name=sc.next();
		System.out.println("Enter color of fruit:");
		color=sc.next();
		System.out.println("Enter weight of fruit:");
		weight=sc.nextDouble();
		System.out.println("Enter isfresh fruits:");
		this.isFresh=sc.nextBoolean();
		
	}
	public void display()
	{
		System.out.println("fruit name="+name);
		System.out.println("fruit color="+color);
		System.out.println("fruit weight="+weight);
		System.out.println("fruit isFresh="+isFresh);
		
	}
	public String taste() {
		// TODO Auto-generated method stub
		return "No specific taste!!!!";
	}
	
	

}

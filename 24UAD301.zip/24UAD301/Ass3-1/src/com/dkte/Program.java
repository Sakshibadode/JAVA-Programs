package com.dkte;

import java.util.Scanner;

public class Program {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		Scanner sc=new Scanner(System.in);
		Fruit[] basket=new Fruit[5];
		int choice;
		int index=0;
		
		do 
		{	
			System.out.println("0. Exit ");
			System.out.println("1.Add Apple ");
			System.out.println("2.Add Mango");
			System.out.println("3.Add Orange");
			System.out.println("4.Display all fruits in the basket.");
			System.out.println("5.Mark a fruit as stale");
			System.out.println("6.display fruits marked as stale.");
			System.out.println("Enter your choice:=");
			choice=sc.nextInt();
			switch(choice)
			{
			case 0:                          
				System.out.println("Exiting!!!!!");
			break;
			case 1:
				if(index<3)
				{
					basket[index]=new Apple();
					basket[index].accept(sc);
					basket[index].display();
					System.out.println("Fruit:"+basket[index].toString());
					System.out.println("Taste:"+basket[index].taste());
					index++;
				}
				else
				{
					System.out.println("basket is full!!");
				}
			break;
			case 2:
				if(index<3)
				{
					basket[index]=new Mango();
					basket[index].accept(sc);
					basket[index].display();
					System.out.println("Fruit:"+basket[index].toString());
					System.out.println("Taste:"+basket[index].taste());
					index++;
				}
				else
				{
					System.out.println("basket is full!!");
				}
			  break;
			case 3:
				if(index<3)
				{
					basket[index]=new Orange();
					basket[index].accept(sc);
					basket[index].display();
					System.out.println("Fruit:"+basket[index].toString());
					System.out.println("Taste:"+basket[index].taste());
					System.out.println("-------------------------------");
					index++;
				}
				else
				{
					System.out.println("basket is full!!");
				}
			    break;
			case 4:
				for(Fruit fruit:basket)
					if(fruit!=null)
			  		fruit.display();
			     break;
			case 5:
				System.out.println("Enter the index mark as stale:");
				int markindex=sc.nextInt();
				if(markindex>=0 && markindex<basket.length && basket[markindex]!=null)
				{
					basket[markindex].setFresh(false);
					System.out.println("marked as stale fruit");
			    }
				else
				{
					System.out.println("marked as fresh fruit");
				}
						
			    break;
			case 6:
				for(Fruit fruit:basket)
					if(fruit!=null)
						if(fruit.isFresh()==false)
							fruit.display();
			     break;
				
				
			default:
				System.out.println("Invalid choice!!!!");
			break;
		
		}
	 }while(choice!=0);
	sc.close();
			
	}

}


package com.dkte;


public class Apple extends Fruit {
	public Apple()
	{
		
	}
	
	public Apple(String name,String color, double weight, boolean isFresh)
	{
		super(name,color,weight,isFresh);
	}
	

	public String taste()
	{
		return  "sweet n sour" ;
	}

	
	

}

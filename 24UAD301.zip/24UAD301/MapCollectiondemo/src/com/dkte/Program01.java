package com.dkte;

import java.util.Collection;
import java.util.HashMap;
import java.util.LinkedHashMap;
import java.util.Map;
import java.util.Set;
import java.util.TreeMap;

public class Program01 {

	public static void main(String[] args) {
	Map<Integer, String> m1 = new HashMap<>();
	
//		Map<Integer, String> m1 = new TreeMap<>();
		m1.put(121, "Anil");
		m1.put(143, "Ramesh");
		m1.put(132, "Mukesh");
		m1.put(132, "Mukesh"); // duplicate key is not allowed
		m1.put(132, "Suresh"); // if the key is same it will replace the value
		m1.put(null, "Ram");
		m1.put(null, "Sham");
		m1.put(154, null); // OK
		m1.put(165, null); // OK Multiple null values are allowed

		System.out.println("size of m1 - " + m1.size());

		System.out.println("Keys - ");
		Set<Integer> keys = m1.keySet();
		for (Integer k : keys)
			System.out.print(k + ",");
		System.out.println();

		System.out.println("Values");
		Collection<String> values = m1.values();
		for (String v : values)
			System.out.print(v + ",");
		System.out.println();


	}

}

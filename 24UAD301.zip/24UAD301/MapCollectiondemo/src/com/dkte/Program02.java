package com.dkte;

import java.util.HashMap;
import java.util.LinkedHashMap;
import java.util.Map;
import java.util.Set;

public class Program02 {

	public static void main(String[] args) {
		Map<Integer, String> m1 = new LinkedHashMap<>();
		m1.put(3, "Anil");
		m1.put(4, "Mukesh");
		m1.put(2, "Ramesh");
		m1.put(1, "Suresh");

		Set<Map.Entry<Integer, String>> keyValue = m1.entrySet();
		for (Map.Entry<Integer, String> element : keyValue) {
			System.out.println(element.getKey() + " - " + element.getValue());
		}
	}

}
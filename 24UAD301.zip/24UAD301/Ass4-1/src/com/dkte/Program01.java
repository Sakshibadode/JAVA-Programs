package com.dkte;

import java.util.Scanner;

public class Program01 {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		Scanner sc=new Scanner(System.in);
		Driving d=new Driving();
		d.accept(sc);
		d.calculate_cost_perday();
		d.display();
		
	}

}

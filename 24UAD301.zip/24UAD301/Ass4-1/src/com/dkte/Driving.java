/*Q1. Create an application that calculates your daily driving cost, so that you can estimate how much 
money could be saved by car pooling, which also has other advantages such as reducing carbon 
emissions and reducing traffic congestion. The application should input the following information 
and display the user’s cost per day of driving to work: 
a) Total miles driven per day. 
b) Cost per gallon of gasoline. 
c) Average miles per gallon. 
d) Parking fees per day. 
e) Tolls per day.*/
package com.dkte;

import java.util.Scanner;

public class Driving {
	double total_milesdriven;
	double cost_pergallon;
	double avg_miles_pergallon;
	double park_fee_perday;
	double tolls_perday;
	
	public Driving()
	{
		
	}
	public Driving(int total_milesdriven,int cost_pergallon,double avg_miles_pergallon,int park_fee_perday,int tolls_perday)
	{
		this.total_milesdriven=total_milesdriven;
		this.cost_pergallon=cost_pergallon;
		this.avg_miles_pergallon=avg_miles_pergallon;
		this.park_fee_perday=park_fee_perday;
		this.tolls_perday=tolls_perday;
	}
	public void accept(Scanner sc)
	{
		System.out.println("Enter total miles driven per day: ");
		total_milesdriven=sc.nextDouble();
		System.out.println("Cost per gallon of gasoline:");
		cost_pergallon=sc.nextDouble();
		System.out.println("Average miles per gallon:");
		avg_miles_pergallon=sc.nextDouble();
		System.out.println("parking fee per day:");
		park_fee_perday=sc.nextDouble();
		System.out.println("Tolls per day:");
		tolls_perday=sc.nextDouble();
		
	}
	public void calculate_cost_perday()
	{
		System.out.println("cost per day driving to work::"+((avg_miles_pergallon*cost_pergallon/total_milesdriven)+park_fee_perday+tolls_perday));
	}
	public void display()
	{
		
		System.out.println("Total miles driven per day:=="+total_milesdriven);
		System.out.println(" Cost per gallon of gasoline:=="+cost_pergallon);
		System.out.println("Average miles per gallon:=="+avg_miles_pergallon);
		System.out.println(" Parking fees per day:=="+park_fee_perday);
		System.out.println("Tolls per day:=="+tolls_perday);
		
	}

}

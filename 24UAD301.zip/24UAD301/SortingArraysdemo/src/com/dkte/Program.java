package com.dkte;

import java.util.Arrays;

public class Program {

	public static void main1(String[] args) {
		// TODO Auto-generated method stub
		String s1[]= {"sita","gita","nita","rita"};
		System.out.println("Before Sorting:"+Arrays.toString(s1));
		Arrays.sort(s1);
		System.out.println("After Sorting:"+Arrays.toString(s1));
	}	
	public static void main(String[] args)
	{
		int i1[]= {10,20,30,40,50,60};
		System.out.println("Before Sorting:"+Arrays.toString(i1));
		Arrays.sort(i1);
		System.out.println("After Sorting:"+Arrays.toString(i1));
	}
	public static void main2(String[] args)
	{
		Double d1[]= {10.0,20.0,30.0,40.0,50.0};
		System.out.println("Before Sorting:"+Arrays.toString(d1));
		Arrays.sort(d1);
		System.out.println("After Sorting:"+Arrays.toString(d1));
		
	}
}



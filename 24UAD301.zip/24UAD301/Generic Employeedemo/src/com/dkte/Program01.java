package com.dkte;

import java.util.Arrays;
//Generic interface
class Employee1 implements Comparable<Employee1>
{
	int id;
	String name;
	double salary;
	public Employee1() {
		
		// TODO Auto-generated constructor stub
	}
	public Employee1(int id, String name, double salary) {
		this.id = id;
		this.name = name;
		this.salary = salary;
	}
	@Override
	public String toString() {
		return "Employee1 [id=" + id + ", name=" + name + ", salary=" + salary + "]";
	}
	/*@Override
	public int compareTo(Employee1 o) {
		// TODO Auto-generated method stub
		return this.id-o.id;
	}
	*/
	/*@Override
	public int compareTo(Employee1 o) {
		// TODO Auto-generated method stub
		return this.name.compareTo(o.name);
	}
	*/
	@Override
	public int compareTo(Employee1 o) {
		// TODO Auto-generated method stub
		return Double.compare(this.salary,o.salary);
	}
	
	
	
	
}

public class Program01 {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		Employee1 arr[]=new Employee1[3];
		arr[0]=new Employee1(102,"Sakshi",20000);
		arr[1]=new Employee1(103,"Nita",10000);
		arr[2]=new Employee1(101,"Gita",30000);
		System.out.println("Before Sorting:");
		for(Employee1 element:arr)
			System.out.println("employee:"+element);
		
		Arrays.sort(arr);
		
		System.out.println("After Sorting:");
		for(Employee1 element:arr)
			System.out.println("employee:"+element);
		
		
		

	}

}

package com.dkte;
//Generic interface

class Employee implements Comparable<Employee>
{
	String name;
	int id;
	
	public Employee()
	{
		
	}
	public Employee(String name,int id)
	{
		this.name=name;
		this.id=id;
	}
	@Override
	public String toString() {
		return "Employee [name=" + name + ", id=" + id + "]";
	}
 @Override
	public int compareTo(Employee o) {
		if(this.id>o.id)
			return 5;
		if(this.id<o.id)
			return -3;
		return 0;
	}
	
/*	@Override
	public int compareTo(Employee o) {
		// TODO Auto-generated method stub
		return this.id-o.id;
	}
	
*/	
	
	
	
}

public class Program {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		Employee e1=new Employee("Sakshi",101);
		Employee e2=new Employee("Sita",102);
		if(e1.compareTo(e2)>0)
			System.out.println("e1 is greater!!");
		else if(e1.compareTo(e2)<0)
			System.out.println("e2 is greater!!");
		else
			System.out.println("Both are equal!!");
		

	}

}

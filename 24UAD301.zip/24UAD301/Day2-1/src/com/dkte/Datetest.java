package com.dkte;

public class Datetest {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		Date d1=new Date(2024,2,1);
		Date d2=new Date(2025,13,2);
		Date d3=new Date(2026,4,3);
		d1.displyaDate();
		d2.displyaDate();
		d3.displyaDate();
		
	}

}

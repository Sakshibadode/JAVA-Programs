package com.dkte;

import java.util.ArrayList;
import java.util.Collections;
import java.util.List;

public class Program01 {

	public static void main(String[] args) {
		List<Integer> l1=new ArrayList<>();
		l1.add(10);
		l1.add(40);
		l1.add(30);
		l1.add(20);
		l1.add(90);
		l1.add(80);
		l1.add(10);
	
		l1.remove(2);
		l1.set(1,60);
        System.out.println("lastindex of 10:"+l1.lastIndexOf(10));
		
		System.out.println("getting value index 2:"+l1.get(2));
		System.out.println("index of 40:"+l1.indexOf(60));
		System.out.println("size of list:"+l1.size());
		System.out.println("Before sorting:");
		for(Integer l:l1)
			System.out.println(l);
		
		Collections.sort(l1);
		
		System.out.println("After sorting:");
		for(Integer l:l1)
			System.out.println(l);
		
		

	}

}

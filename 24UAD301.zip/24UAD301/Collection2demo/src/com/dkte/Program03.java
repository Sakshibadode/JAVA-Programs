package com.dkte;


	import java.util.Vector;

	public class Program03 {

		public static void main(String[] args) {
			Vector<Integer> v1 = new Vector<>();
				v1.add(10);
			    v1.addElement(20);

			for (int i = 1; i <= 10; i++)
				v1.add(i);

			for (int i = 1; i <= 10; i++)
				v1.add(i + 10);

			v1.add(21);

			System.out.println("size of vector - " + v1.size());
			System.out.println("capacity of vector - " + v1.capacity());

			for (Integer e : v1)
				System.out.println("element - " + e);

		}

	}



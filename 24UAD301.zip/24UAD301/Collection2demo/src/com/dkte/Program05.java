package com.dkte;

import java.util.Collections;
import java.util.Comparator;
import java.util.LinkedList;
import java.util.List;

class Product implements Comparable<Product> {
	int pid;
	String name;
	double price;

	public Product() {
	}

	public Product(int pid) {
		this.pid = pid;
	}

	public Product(int pid, String name, double price) {
		this.pid = pid;
		this.name = name;
		this.price = price;
	}

	@Override
	public boolean equals(Object obj) {
		if (this == obj)
			return true;
		if (!(obj instanceof Product))
			return false;
		Product other = (Product) obj;
		return pid == other.pid;
	}

	@Override
	public String toString() {
		return "Product [pid=" + pid + ", name=" + name + ", price=" + price + "]";
	}

	// natural ordering of the products
	@Override
	public int compareTo(Product o) {
		return this.pid - o.pid;
	}

}

public class Program05 {

	public static void main(String[] args) {
		List<Product> products = new LinkedList<>();
		products.add(new Product(5, "Pen", 20));
		products.add(new Product(1, "Pencil", 5));
		products.add(new Product(3, "Scale", 10));
		products.add(new Product(2, "Book", 50));
		products.add(new Product(4, "Eraser", 5));

		System.out.println("Before Sorting ->");
		for (Product product : products)
			System.out.println(product);

		class ProductNameComparator implements Comparator<Product> {
			@Override
			public int compare(Product p1, Product p2) {
				return p1.name.compareTo(p2.name);
			}
		}

		ProductNameComparator productNameComparator = new ProductNameComparator();
		Collections.sort(products, productNameComparator);

		System.out.println("After Sorting on name ->");
		for (Product product : products)
			System.out.println(product);
	}

	public static void main2(String[] args) {
		List<Product> products = new LinkedList<>();
		products.add(new Product(5, "Pen", 20));
		products.add(new Product(1, "Pencil", 5));
		products.add(new Product(3, "Scale", 10));
		products.add(new Product(2, "Book", 50));
		products.add(new Product(4, "Eraser", 5));

		System.out.println("Before Sorting ->");
		for (Product product : products)
			System.out.println(product);

		Collections.sort(products);

		System.out.println("After Sorting ->");
		for (Product product : products)
			System.out.println(product);
	}

	public static void main1(String[] args) {
		List<Product> products = new LinkedList<>();
		products.add(new Product(5, "Pen", 20));
		products.add(new Product(1, "Pencil", 5));
		products.add(new Product(3, "Scale", 10));
		products.add(new Product(2, "Book", 50));
		products.add(new Product(4, "Eraser", 5));

		System.out.println("product at index 3 - " + products.get(3));
		System.out.println("index of product with id 2 = " + products.indexOf(new Product(2)));
		products.remove(2);

		for (Product product : products)
			System.out.println(product);
	}

}


package com.dkte;

import java.util.ArrayList;

public class Program02 {



	public static void main(String[] args) {
		ArrayList<Integer> l1 = new ArrayList<>();
		l1.add(10);
		l1.add(20);
		l1.add(20);
		l1.add(30);
		l1.add(40);
		l1.add(50);

		for (Integer e : l1)
			System.out.println("element - " + e);
	}

}


package com.dkte2;

import java.awt.List;
import java.io.DataInputStream;
import java.io.DataOutputStream;
import java.io.EOFException;
import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.util.ArrayList;

public class Program {

	public static void main1(String[] args) {
		// TODO Auto-generated method stub
		Product p=new Product(1,"Mobile",90000.0);
		String path="C:\\Users\\Sakshi\\Documents\\filedemo\\file2.txt";
		try(FileOutputStream in=new FileOutputStream(path))
		{
			try(DataOutputStream dout=new DataOutputStream(in))
			{
				dout.writeInt(p.getPid());
				dout.writeUTF(p.getName());
				dout.writeDouble(p.getPrice());
				System.out.println("file saved!!!");
			}
		}
		catch(Exception e)
		{
			e.printStackTrace();
		}
	}
	
	public static void main2(String[] args) {
		// TODO Auto-generated method stub
		
		String path="C:\\Users\\Sakshi\\Documents\\filedemo\\file2.txt";
		try(FileInputStream in=new FileInputStream(path))
		{
			try(DataInputStream din=new DataInputStream(in))
			{
				int pid=din.readInt();
				String name=din.readUTF();
				double price=din.readDouble();
				Product p=new Product(pid,name,price);
				System.out.println("file read:"+p);
			}
		}
		catch(Exception e)
		{
			e.printStackTrace();
		}
	}
	
	public static void main3(String[] args) {
		// TODO Auto-generated method stub
		ArrayList<Product> list=new ArrayList<>();
		
		list.add(new Product(2,"pen",10.0));
		list.add(new Product(3,"pencil",20.0));
		
		String path="C:\\Users\\Sakshi\\Documents\\filedemo\\file3.txt";
		try(FileOutputStream in=new FileOutputStream(path))
		{
			try(DataOutputStream dout=new DataOutputStream(in))
			{
				for(Product p:list)
				{
					dout.writeInt(p.getPid());
					dout.writeUTF(p.getName());
					dout.writeDouble(p.getPrice());
					System.out.println("file saved!!!");
				}
			}
		}
		catch(Exception e)
		{
			e.printStackTrace();
		}
	}
	
	public static void main(String[] args) {
		// TODO Auto-generated method stub
		ArrayList<Product> list=new ArrayList<>();
		String path="C:\\Users\\Sakshi\\Documents\\filedemo\\file3.txt";
		try(FileInputStream in=new FileInputStream(path))
		{
			try(DataInputStream din=new DataInputStream(in))
			{
				while(true)
				{
					int pid=din.readInt();
					String name=din.readUTF();
					double price=din.readDouble();
					Product p=new Product(pid,name,price);
					list.add(p);
					System.out.println("file read:"+p);
				}
			}
		}
		catch(EOFException e)
		{
			System.out.println("All Records Read: " + list.size());
		}
		catch(Exception e)
		{
			e.printStackTrace();
		}
	}

}

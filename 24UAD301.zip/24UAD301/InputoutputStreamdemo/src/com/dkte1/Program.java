package com.dkte1;

import java.io.FileOutputStream;
import java.io.PrintStream;
import java.util.Scanner;

public class Program {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		Scanner sc=new Scanner(System.in);
		System.out.println("Enter a text to write in a file:");
		String path="C:\\Users\\Sakshi\\Documents\\filedemo\\file.txt";
		try(FileOutputStream fout=new FileOutputStream(path))      //Write bytes in file
		{
			try(PrintStream pout=new PrintStream(fout))   //printable characters to byte conversion
			{
				while(true) {
					String line = sc.nextLine();
					if(line.isEmpty())
						break;
					pout.println(line);
				}
				System.out.println("File Saved.");
			}
		}
		catch(Exception e)
		{
			e.printStackTrace();
		}
		
				

	}

}

package com.dkte1;

import java.io.FileInputStream;
import java.util.Scanner;

public class Program01 {
	public static void main(String[] args) {
		String path = "C:\\Users\\Sakshi\\Documents\\filedemo\\file.txt";
		String line = "";
		try(FileInputStream fin = new FileInputStream(path)) {
			try(Scanner sc = new Scanner(fin)) {
				while(sc.hasNextLine()) {
					line = sc.nextLine();
					System.out.println(line);
				}
			} // sc.close();
		} // fin.close();
		catch (Exception e) {
			e.printStackTrace();
		}
	}
}




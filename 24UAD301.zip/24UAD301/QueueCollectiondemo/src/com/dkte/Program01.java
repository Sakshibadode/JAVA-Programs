package com.dkte;

import java.util.ArrayDeque;
import java.util.LinkedList;
import java.util.Queue;

public class Program01 {

	public static void main(String[] args) {
	//	Queue<Integer> q1=new ArrayDeque<>();
		Queue<Integer> q1=new LinkedList<>();
		q1.add(10);
		q1.add(20);
		q1.offer(30);
		q1.offer(40);

		System.out.println("Element at first - " + q1.element());
		System.out.println("Element at first - " + q1.peek());

		q1.remove();
		q1.poll();
		q1.poll();
		q1.remove();

//		q1.poll();
		q1.remove();

		System.out.println("After remove, Element at first - " + q1.peek());
		// System.out.println("After remove, Element at first - " + q1.element());

		

	}

}

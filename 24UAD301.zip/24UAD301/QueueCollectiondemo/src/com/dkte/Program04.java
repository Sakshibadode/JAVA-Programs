package com.dkte;

import java.util.Comparator;
import java.util.PriorityQueue;
import java.util.Queue;

class Product implements Comparable<Product> {
	int pid;
	String name;
	double price;

	public Product() {
	}

	public Product(int pid) {
		this.pid = pid;
	}

	public Product(int pid, String name, double price) {
		this.pid = pid;
		this.name = name;
		this.price = price;
	}

	@Override
	public boolean equals(Object obj) {
		if (this == obj)
			return true;
		if (!(obj instanceof Product))
			return false;
		Product other = (Product) obj;
		return pid == other.pid;
	}

	@Override
	public String toString() {
		return "Product [pid=" + pid + ", name=" + name + ", price=" + price + "]";
	}

	@Override
	public int compareTo(Product o) {
		return this.pid - o.pid;
	}

}

public class Program04 {

	public static void main(String[] args) {
//		Queue<Product> products = new PriorityQueue<Product>();

		class ProductPriceComparator implements Comparator<Product> {
			@Override
			public int compare(Product o1, Product o2) {
				return Double.compare(o2.price, o1.price);
			}
		}
		ProductPriceComparator priceComparator = new ProductPriceComparator();

		Queue<Product> products = new PriorityQueue<Product>(priceComparator);
		products.add(new Product(3, "Scale", 10));
		products.add(new Product(5, "Pen", 20));
		products.add(new Product(1, "Pencil", 5));
		products.add(new Product(2, "Book", 50));
		products.add(new Product(4, "Eraser", 5));

		System.out.println("Product at first - " + products.peek());
		System.out.println("Product remove - " + products.remove());
		System.out.println("After remove Product at first - " + products.peek());

	}

}

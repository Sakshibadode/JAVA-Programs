package com.dkte;

import java.util.ArrayDeque;
import java.util.Deque;

public class Program02 {
	public static void main(String[] args) {
		Deque<Integer> q1 = new ArrayDeque<>();
		q1.addFirst(10);
		q1.addFirst(20);
		q1.addLast(30);
		System.out.println("Peek - " + q1.peek());

		q1.push(40);
		q1.pop();
		
	}

}
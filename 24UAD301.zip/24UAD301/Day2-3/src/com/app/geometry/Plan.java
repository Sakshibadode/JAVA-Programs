package com.app.geometry;
class Plan{
	int X;
	int Y;
	public Plan(int X,int Y){
		this.X=X;
		this.Y=Y;
	}
	public String getDetails() {
		String line="x co-ord: "+ X+" & y co-ord: "+Y;
		return line;
	}
	
	
}

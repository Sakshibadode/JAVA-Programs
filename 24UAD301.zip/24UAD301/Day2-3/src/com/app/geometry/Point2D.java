package com.app.geometry;

public class Point2D {

	public static void main(String[] args) {
		Plan p1=new Plan(2,4);
		Plan p2 = new Plan(3,4);
		System.out.println(p1.getDetails());
		System.out.println(p2.getDetails());
		if(isEqual(p1,p2)) {
			System.out.println("both Points are having same x & y co-ords");
		}else {
			System.out.println("both Points are having diffrent x & y co-ord");
		}
		double D = calculateDistance(p1,p2);
		System.out.println("Distance :"+D);
		

	}

	private static double calculateDistance(Plan p1, Plan p2) {
		double distance;
		distance=(Math.pow((p2.X-p1.X),2)+Math.pow((p2.Y-p1.Y),2));
		distance= Math.sqrt(distance);
		return distance;
		
	}
	private static boolean isEqual(Plan p1,Plan p2) {
		if(p1.X==p2.X) {
			if(p1.Y==p2.Y) {
			return true;
			}
		}
		return false;
	}

}

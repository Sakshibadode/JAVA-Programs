package com.dkte;

import java.util.LinkedHashSet;
import java.util.Objects;
import java.util.Set;
import java.util.TreeSet;

class Products implements Comparable<Products>
{
	int id;
	String name;
	double price;
	
	public Products()
	{
		
	}
	public Products(int id,String name,double price)
	{
		this.id=id;
		this.name=name;
		this.price=price;
	}
	@Override
	public String toString() {
		return "Product [id=" + id + ", name=" + name + ", price=" + price + "]";
	}
	
	@Override
	public int compareTo(Products o) {
		// TODO Auto-generated method stub
		return this.id-o.id;
	}
	
}
public class Program3 {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		Set<Products> s=new TreeSet<>();
		s.add(new Products(101,"pen",10));
		s.add(new Products(104,"book",35));
		s.add(new Products(102,"eraser",8));
		s.add(new Products(103,"notebook",20));
		s.add(new Products(106,"pencil",9));
		s.add(new Products(102,"eraser",8));
		
		System.out.println("size:"+s.size());

		for(Products product:s)
			System.out.println(product);
		

	}

}

package com.dkte;

import java.util.LinkedHashSet;
import java.util.Objects;
import java.util.Set;

class Product
{
	int id;
	String name;
	double price;
	
	public Product()
	{
		
	}
	public Product(int id,String name,double price)
	{
		this.id=id;
		this.name=name;
		this.price=price;
	}
	@Override
	public String toString() {
		return "Product [id=" + id + ", name=" + name + ", price=" + price + "]";
	}
	@Override
	public int hashCode() {
		return Objects.hash(id);
	}
	@Override
	public boolean equals(Object obj) {
		if (this == obj)
			return true;
		if (!(obj instanceof Product))
			return false;
		Product other = (Product) obj;
		return id == other.id;
	}
	
}
public class Program02 {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		Set<Product> s1=new LinkedHashSet<>();
		s1.add(new Product(101,"pen",10));
		s1.add(new Product(104,"book",35));
		s1.add(new Product(102,"eraser",8));
		s1.add(new Product(103,"notebook",20));
		s1.add(new Product(106,"pencil",9));
		s1.add(new Product(102,"eraser",8));
		
		System.out.println("size:"+s1.size());
		
		for(Product products:s1)
			System.out.println(products);
		

	}

}

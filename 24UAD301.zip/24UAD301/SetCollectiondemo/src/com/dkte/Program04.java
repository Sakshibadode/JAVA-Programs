package com.dkte;

import java.util.Comparator;
import java.util.Set;
import java.util.TreeSet;

class Prodoc implements Comparable<Prodoc>
{
	int id;
	String name;
	double price;
	
	public Prodoc()
	{
		
	}
	
	public Prodoc(int id,String name,double price)
	{
		this.id=id;
		this.name=name;
		this.price=price;
	}
	@Override
	public String toString() {
		return "Prodoc [id=" + id + ", name=" + name + ", price=" + price + "]";
	}

	@Override
	public int compareTo(Prodoc o) {
		// TODO Auto-generated method stub
		return this.id-o.id;
	}
	
	
}

public class Program04 {
	public static void main1(String[] args) {
	class NameComparator implements Comparator<Prodoc>
	{

		@Override
		public int compare(Prodoc o1, Prodoc o2) {
			// TODO Auto-generated method stub
			return o1.name.compareTo(o2.name);
		}
		
	}
	NameComparator namecomparator=new NameComparator();

	
		Set<Prodoc> s=new TreeSet<>(namecomparator);
		s.add(new Prodoc(106,"book",35));
		s.add(new Prodoc(102,"pencil",9));
		s.add(new Prodoc(101,"pen",10));
		s.add(new Prodoc(105,"eraser",5));
		s.add(new Prodoc(103,"notebook",50));
		
		System.out.println("size:"+s.size());
		for(Prodoc p:s)
			System.out.println(p);

	}
	public static void main(String[] args) {
		class PriceComparator implements Comparator<Prodoc>
		{

			@Override
			public int compare(Prodoc o1, Prodoc o2) {
				// TODO Auto-generated method stub
				return Double.compare(o2.price, o1.price);
			}
			
		}
		PriceComparator pricecomparator=new PriceComparator();

		
			Set<Prodoc> s=new TreeSet<>(pricecomparator);
			s.add(new Prodoc(106,"book",35));
			s.add(new Prodoc(102,"pencil",9));
			s.add(new Prodoc(101,"pen",10));
			s.add(new Prodoc(105,"eraser",5));
			s.add(new Prodoc(103,"notebook",50));
			
			System.out.println("size:"+s.size());
			for(Prodoc p:s)
				System.out.println(p);

		}

}

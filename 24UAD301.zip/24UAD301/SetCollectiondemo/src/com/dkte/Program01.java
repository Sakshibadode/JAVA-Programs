package com.dkte;

import java.util.HashSet;
import java.util.LinkedHashSet;
import java.util.Set;
import java.util.TreeSet;

public class Program01 {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		Set<String> s1=new HashSet<>();
	//	Set<String> s1=new LinkedHashSet<>();
	//	Set<String> s1=new TreeSet<>();
		s1.add("sita");
		s1.add("nita");
		s1.add("anita");
		s1.add("gita");
		s1.add("rita");
		s1.add("rita");       //duplication is not allowed in set
		
		System.out.println("size of set:"+s1.size());
		for(String s:s1)
			System.out.println(s);

	}

}

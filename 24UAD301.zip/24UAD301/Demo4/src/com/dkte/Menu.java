package com.dkte;

import java.util.Scanner;

public class Menu {
	
	public static void Hotel_menu(Scanner sc)
	{
			
	}

	public static void main(String[] args) {
		// TODO Auto-generated method stub

	}

}

package com.dkte;

public class program01 {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		Setterdemo s=new Setterdemo("paneer",10.0);
		Setterdemo s1=new Setterdemo("roti",20.0);
		s.display();
		s1.display();

	}

}

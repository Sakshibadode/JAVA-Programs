package com.dkte1;

public class Demo02Main {
	public static void main(String[] args) {
		MyWindow wnd = new MyWindow();
		wnd.setVisible(true);
	}
}


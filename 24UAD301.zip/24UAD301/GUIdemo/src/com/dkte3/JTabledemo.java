package com.dkte3;

import javax.swing.JButton;
import javax.swing.JFrame;
import javax.swing.JOptionPane;
import javax.swing.JScrollPane;
import javax.swing.JTable;
import javax.swing.table.DefaultTableModel;

public class JTabledemo extends JFrame{
	private DefaultTableModel producttablemodel;
	private JTable pTable;
	private JScrollPane jscrollpane;
	private JButton addbutton,deletebutton,exitbutton;
	
	public JTabledemo()
	{
		this.setTitle("Product Data Table");
		this.setSize(600, 400);
		this.setDefaultCloseOperation(DISPOSE_ON_CLOSE);
		this.setLayout(null);
		
		Object[] column= {"id","name","price"};
		
		producttablemodel=new DefaultTableModel(column,0);
		pTable=new JTable(producttablemodel);
		jscrollpane=new JScrollPane(pTable);
		jscrollpane.setBounds(20, 20, 550, 250);
		this.add(jscrollpane);
	
		addbutton = new JButton("Add");
		addbutton.setBounds(100, 300, 100, 30);
		this.add(addbutton);

		deletebutton = new JButton("Delete");
		deletebutton.setBounds(250, 300, 100, 30);
		this.add(deletebutton);
		
		exitbutton = new JButton("Exit");
		exitbutton.setBounds(400, 300, 100, 30);
		this.add(exitbutton);
		
		addbutton.addActionListener((e)->{
			ProductDialog dlg=new ProductDialog();
			dlg.setModal(true);
			dlg.setVisible(true);
			Product prod = dlg.getProduct();
			// add the data in table model
			Object[] row = {prod.getId(), prod.getName(), prod.getPrice()};
			producttablemodel.addRow(row);
		});
		
		deletebutton.addActionListener((e) -> {
			// get selected row index
			int rowIndex = pTable.getSelectedRow();
			if(rowIndex == -1) {
				JOptionPane.showMessageDialog(this, "No Row is Selected");
				return;
			}
			// delete the row from table model
			producttablemodel.removeRow(rowIndex);
		});
		
		exitbutton.addActionListener((e) -> this.dispose() );
			
			
		
	}

}

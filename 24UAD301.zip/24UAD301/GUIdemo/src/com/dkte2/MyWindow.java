package com.dkte2;

import java.awt.event.ActionListener;

import javax.swing.JButton;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JOptionPane;
import javax.swing.JTextArea;
import javax.swing.JTextField;

public class MyWindow extends JFrame{
	private JLabel num1;
	private JTextField num1TextField;
	private JLabel num2;
	private JTextField num2TextField;
	private JLabel result;
	private JTextField resultTextField;
	private JButton AddButton;
	private JButton SubButton;
	private JButton MulButton;
	
	public MyWindow()
	{
		this.setTitle("Airthmetic Operations");
		this.setSize(800, 600);
		this.setDefaultCloseOperation(DISPOSE_ON_CLOSE);
		this.setLayout(null);
		
		num1=new JLabel("Number1:");
		num1.setBounds(100, 100, 80, 30);
		this.add(num1);
		
		num1TextField=new JTextField();
		num1TextField.setBounds(300, 100, 80, 30);
		this.add(num1TextField);
		
		num2=new JLabel("Number2:");
		num2.setBounds(100,200, 80, 30);
		this.add(num2);
		
		num2TextField=new JTextField();
		num2TextField.setBounds(300, 200, 80, 30);
		this.add(num2TextField);
		
		result=new  JLabel("Result:");
		result.setBounds(100, 300,80, 30);
		this.add(result);
		
		resultTextField=new JTextField();
		resultTextField.setBounds(300,300, 80, 30);
		this.add(resultTextField);
		
		AddButton=new JButton("ADD");
		AddButton.setBounds(100,400,80,30);
		this.add(AddButton);
		
		SubButton=new JButton("SUB");
		SubButton.setBounds(300,400,80,30);
		this.add(SubButton);
		
		MulButton=new JButton("MULTIPLY");
		MulButton.setBounds(500,400,80,30);
		this.add(MulButton);
	/*	
		AddButton.addActionListener((e)->
		{
			int n1=Integer.parseInt(num1TextField.getText());
			int n2=Integer.parseInt(num2TextField.getText());
			int res=n1+n2;
			String message="Addition:"+res;
			JOptionPane.showMessageDialog(this, message);
		});
			
		SubButton.addActionListener((e)->
		{
			int n1=Integer.parseInt(num1TextField.getText());
			int n2=Integer.parseInt(num2TextField.getText());
			int res=n1-n2;
			String message="Substraction:"+res;
			JOptionPane.showMessageDialog(this, message);
		});
		
		MulButton.addActionListener((e)->
		{
			int n1=Integer.parseInt(num1TextField.getText());
			int n2=Integer.parseInt(num2TextField.getText());
			int res=n1*n2;
			String message="Multiplication:"+res;
			JOptionPane.showMessageDialog(this, message);
		});
		*/
		
		ActionListener listener=((e)->
		{
			int n1=Integer.parseInt(num1TextField.getText());
			int n2=Integer.parseInt(num2TextField.getText());
			int result = 0;
			String cmd=e.getActionCommand();
			
			if(cmd.equals(("ADD")))
				result=n1+n2;
			
			if(cmd.equals(("SUB")))
				result=n1-n2;
			
			if(cmd.equals("MUL"))
				result=n1*n2;
			
			String message="Result:"+result;
			JOptionPane.showMessageDialog(this, message);
		});
		
		AddButton.setActionCommand("ADD");
		SubButton.setActionCommand("SUB");
		MulButton.setActionCommand("MUL");
		
		AddButton.addActionListener(listener);
		SubButton.addActionListener(listener);
		MulButton.addActionListener(listener);
	}
	
	

}

package com.dkte;

public class Progrm01 {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		MyWindow win=new MyWindow();
		win.setVisible(true);
	}

}

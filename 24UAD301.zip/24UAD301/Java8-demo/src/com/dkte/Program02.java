package com.dkte;


interface Displayable {
	default void print() {
		System.out.println("Displayable");
	}
}

interface Showable {
	default void print() {
		System.out.println("Showable");
	}
}

class Date implements Displayable, Showable {
	@Override
	public void print() {
		Displayable.super.print();
		System.out.println("Test::display");
	}
}

public class Program02 {

	public static void main(String[] args) {
//		Acceptable a = new Employee();
//		Acceptable a = new Time();
		Acceptable a = new Date();
		a.accept();
		a.display();
		a.print();
	}

}


package com.dkte;

import java.util.Scanner;

public class Vehicle {
	String name;
	int number;

	
	public Vehicle()
	{
	}
	public Vehicle(String name,int number)
	{
		this.name=name;
		this.number=number;

		
	}
	public void acceptVehicle(Scanner sc)
	{
		System.out.println("Enter name of veh:=");
		name=sc.next();
		System.out.println("Enter number of veh:=");
		number=sc.nextInt();
		
		
	}
	public void displayVehicle()
	{
		System.out.println("nameveh:="+name);
		System.out.println("numberveh:="+number);
	
	}
	

}

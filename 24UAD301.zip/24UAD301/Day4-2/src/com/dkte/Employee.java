package com.dkte;

import java.util.Scanner;

public class Employee {
	int empid;
	String name;
	Date doj;
	Vehicle v;
	
	public Employee()
	{
		doj=new  Date();
	}
	public Employee(int empid,String name,int day,int month,int year)
	{
		this.empid=empid;
		this.name=name;
		this.doj=new Date(day,month,year);
		
	}

	public void accept1(Scanner sc)
	{
		
		System.out.println("Enter ID:=");
		empid=sc.nextInt();
		System.out.println("Enter name:=");
		name=sc.next();
		System.out.println("Enter date of joining:=");
		doj.accept(sc);
	}
	public void addVehicle(Scanner sc)
	{
		v=new Vehicle();
		v.acceptVehicle(sc);
		
	}
	
	
	public void display1()
	{
		
		System.out.println("Empid:="+empid);
		System.out.println("name:="+name);
		doj.display();
		v.displayVehicle();
	}
	
	
}

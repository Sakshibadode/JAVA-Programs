package com.dkte;

import java.util.Scanner;

public class program {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		Scanner sc=new Scanner(System.in);
		Employee e1=new Employee();
		e1.accept1(sc);
		e1.addVehicle(sc);
		e1.display1();
		

	}

}

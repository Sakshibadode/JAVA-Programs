package com.dkte;

import java.util.Scanner;

public class Date {
	int day;
	int month;
	int year;
	
	public Date()
	{
		
	}
	public Date(int day,int month,int year)
	{
		this.day=day;
		this.month=month;
		this.year=year;
	}
	public void accept(Scanner sc)
	{
		System.out.println("Enter Day:=");
		day=sc.nextInt();
		System.out.println("Enter month:=");
		month=sc.nextInt();
		System.out.println("Enter year:=");
		year=sc.nextInt();
	}
	public void display()
	{
		System.out.println("Date:="+day+"/"+month+"/"+year);
	}
	
}

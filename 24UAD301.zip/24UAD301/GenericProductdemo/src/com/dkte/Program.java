package com.dkte;

import java.util.Arrays;
//Generic Iterface
class Product implements Comparable<Product>
{
	int id;
	String name;
	Double price;
	public Product() {
		
		// TODO Auto-generated constructor stub
	}
	public Product(int id, String name, Double price) {
	
		this.id = id;
		this.name = name;
		this.price = price;
	}
	@Override
	public String toString() {
		return "Product [id=" + id + ", name=" + name + ", price=" + price + "]";
	}
	/*@Override
	public int compareTo(Product o) {
		// TODO Auto-generated method stub
		return this.id-o.id;
	}
	*/
	/*@Override
	public int compareTo(Product o) {
		// TODO Auto-generated method stub
		return this.name.compareTo(o.name);
	}
	*/
	@Override
	public int compareTo(Product o) {
		// TODO Auto-generated method stub
		return Double.compare(this.price,o.price);
	}
	
	
}

public class Program {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		Product arr[]=new Product[3];
		arr[0]=new Product(103,"bottle",11.0);
		arr[1]=new Product(101,"pen",15.0);
		arr[2]=new Product(106,"ring",9.0);
		
		System.out.println("Befor Sorting:");
		for(Product p:arr)
			System.out.println("Products:"+p);
		
		Arrays.sort(arr);
		
		System.out.println("After Sorting:");
		for(Product p:arr)
			System.out.println("Products:"+p);
		

	}

}

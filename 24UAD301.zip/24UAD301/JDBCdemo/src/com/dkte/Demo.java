/*
Write a Menu driven program for E-commerce application. Provide following functionalities.
1. Sign Up
2. Sign In
3. Sign Out
4. Admin - Add Product
5. Admin - Delete Product
6. Admin - Update Product
7. Admin - Change Order Status
8. Customer - Display All Products
9. Customer - Find Product
10. Customer - Place Order
*/
package com.dkte;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Timestamp;
import java.util.Scanner;

public class Demo {
	private static Scanner sc=new Scanner(System.in);
	
	private static User curuser=null;
	
	public static void SignUp() throws SQLException
	{
		System.out.println("User Registration");
		System.out.println("Enter name:");
		String name=sc.next();
		System.out.println("Enter Email:");
		String email=sc.next();
		System.out.println("Enter password:");
		String pass=sc.next();
		System.out.println("Enter address:");
		String addr=sc.next();
		
		try(Connection con=Dbutil.getConnection())
		{
			String sql="INSERT INTO users(id,name,email,pass,addr) VALUES(Default,?,?,?,?)";
			try(PreparedStatement stmt=con.prepareStatement(sql))
				{
					stmt.setString(1,name);
					stmt.setString(2,email);
					stmt.setString(3,pass);
					stmt.setString(4,addr);
					
					int count=stmt.executeUpdate();
					System.out.println("User Registered!:="+count);	
				}
		}
		catch(Exception e)
		{
			e.printStackTrace();
		}	
	}
	public static void signIn() throws SQLException
	{
		System.out.println("Enter email:");
		String email=sc.next();
		System.out.println("Enter Password:");
		String pass=sc.next();
		try(Connection con=Dbutil.getConnection())
		{
			String sql="SELECT *FROM users WHERE email=? AND pass=?";
			try(PreparedStatement stmt=con.prepareStatement(sql))
			{
				stmt.setString(1,email);
				stmt.setString(2,pass);
				ResultSet rs=stmt.executeQuery();
				if(rs.next())
				{
					int id=rs.getInt("id");
					String name=rs.getString("name");
					String addr=rs.getString("addr");
					curuser=new User(id,name,email,pass,addr);
					System.out.println("login successful");
				}
				else
				{
					System.out.println("Login failed!!!");
				}
			}
		}
		catch(Exception e)
		{
			e.printStackTrace();
		}
	}
	public static void signOut()
	{
		curuser=null;
	}
	public static void addProduct() throws SQLException
	{
		if(curuser==null)
		{
			System.out.println("User is not loged in!!");
			return;
		}
		if(!curuser.getName().equals("Admin"))
		{
			System.out.println("you are not admin!");
			return;
		}
		try(Connection con=Dbutil.getConnection())
		{
			String sql="INSERT INTO products VALUES(Default,?,?)";
			try(PreparedStatement stmt=con.prepareStatement(sql))
			{
				System.out.println("Enetr name:");
				String name=sc.next();
				System.out.println("Enter price");
				double price=sc.nextDouble();
				stmt.setString(1,name);
				stmt.setDouble(2,price);
				
				int count=stmt.executeUpdate();
				System.out.println("product:"+count);	
			}
		}
		catch(Exception e)
		{
			e.printStackTrace();
		}
	}
	public static void updateProduct() throws SQLException
	{
		if(curuser==null)
		{
			System.out.println("user is not loged in!!");
			return;
		}
		if(!curuser.getName().equals("Admin"))
		{
			System.out.println("You are not Admin!!");
			return;
		}
		try(Connection con=Dbutil.getConnection())
		{
			String sql="UPDATE products set name=?,price=? WHERE id=?";
			try(PreparedStatement stmt=con.prepareStatement(sql))
			{
				System.out.println("Enter id:");
				Integer id=sc.nextInt();
				System.out.println("Enter name:");
				String name=sc.next();
				System.out.println("Enter price:");
				double price=sc.nextDouble();
				stmt.setString(2, name);
				stmt.setInt(1,id);
				stmt.setDouble(3, price);
				
				int count=stmt.executeUpdate();
				System.out.println("Update record:"+count);
			}
		}
		catch(Exception e)
		{
			e.printStackTrace();
		}
	}
	public static void deleteProduct() throws SQLException
	{
		if(curuser==null)
		{
			System.out.println("user is not loged in!!");
			return;
		}
		if(!curuser.getName().equals("Admin"))
		{
			System.out.println("You are not admin!!");
			return;
		}
		try(Connection con=Dbutil.getConnection())
		{
			String sql="DELETE products WHERE id=?";
			try(PreparedStatement stmt=con.prepareStatement(sql))
			{
				System.out.println("Enter id:");
				Integer id=sc.nextInt();
				stmt.setInt(1,id);
				int count=stmt.executeUpdate();
				System.out.println("Deleted record:"+count);
			}
		}
		catch(Exception e)
		{
			e.printStackTrace();
		}
	}
	public static void displayallProduct() throws SQLException
	{
		if(curuser==null)
		{
			System.out.println("You are not loged in!!!");
			return;
		}
		try(Connection con=Dbutil.getConnection())
		{
			String sql="SELECT *FROM products";
			try(PreparedStatement stmt=con.prepareStatement(sql))
			{
				ResultSet rs=stmt.executeQuery();
				while(rs.next())
				{
					int id=rs.getInt("id");
					String name=rs.getString("name");
					double price=rs.getDouble("price");
					System.out.println(id+","+name+","+price);
				}
			}
		}
		catch(Exception e)
		{
			e.printStackTrace();
		}
		
	}
	public static void placeOrder() throws SQLException
	{
		if(curuser==null)
		{
			System.out.println("user is not loged in!!");
			return;
		}
		System.out.println("Enter product id to purchase:");
		int prod_id=sc.nextInt();
		
		try(Connection con=Dbutil.getConnection())
		{
			String sql= "INSERT INTO orders VALUES(default,?,?,NOW(),'pending!')";
			try(PreparedStatement stmt=con.prepareStatement(sql))
			{
				stmt.setInt(1,curuser.getId());
				stmt.setInt(2, prod_id);
				int count=stmt.executeUpdate();
				System.out.println("ordered product:"+count);
			}
				
		}
		catch(Exception e)
		{
			e.printStackTrace();
		}
	}
	public static void changeOrderStatus() {
	    if (curuser == null || !curuser.getName().equals("Admin")) {
	        System.out.println("Only Admin can change order status.");
	        return;
	    }

	    try (Connection con = Dbutil.getConnection()) {
	        System.out.print("Enter Order ID: ");
	        int orderId = sc.nextInt();
	        System.out.print("Enter New Status (Pending/Shipped/Delivered): ");
	        String status = sc.next();

	        String sql = "UPDATE orders SET status=? WHERE id=?";
	        try (PreparedStatement stmt = con.prepareStatement(sql)) {
	            stmt.setString(1, status);
	            stmt.setInt(2, orderId);
	            int count = stmt.executeUpdate();
	            System.out.println("Orders Updated: " + count);
	        }
	    } catch (Exception e) {
	        e.printStackTrace();
	    }
	}
	
	public static void findProduct() throws SQLException {
	    if(curuser == null) {
	        System.out.println("Please login first.");
	        return;
	    }

	    System.out.println("Enter product name to search:");
	    sc.nextLine(); // Flush buffer
	    String keyword = sc.nextLine();

	    try (Connection con = Dbutil.getConnection()) {
	        String sql = "SELECT * FROM products WHERE name LIKE ?";
	        try (PreparedStatement stmt = con.prepareStatement(sql)) {
	            stmt.setString(1, "%" + keyword + "%");
	            try (ResultSet rs = stmt.executeQuery()) {
	                boolean found = false;
	                while (rs.next()) {
	                    found = true;
	                    int id = rs.getInt("id");
	                    String name = rs.getString("name");
	                    double price = rs.getDouble("price");
	                    System.out.println(id + ", " + name + ", " + price);
	                }
	                if (!found) {
	                    System.out.println("No matching products found.");
	                }
	            }
	        }
	    }
	}


	public static void showCustmoerOrder() throws SQLException
	{
	if(curuser == null) {
		System.out.println("User is not Logged In.");
		return;
	}
	if(curuser.getName().equals("Admin")) {
		System.out.println("You are not Customer.");
		return;
	}
	
	try(Connection con = Dbutil.getConnection()) {
		String sql = "SELECT p.id, p.name, p.price, o.order_dt, o.status FROM products p INNER JOIN orders o ON o.prod_id = p.id WHERE o.user_id=?";
		try(PreparedStatement stmt = con.prepareStatement(sql)) {
			stmt.setInt(1, curuser.getId());
			try(ResultSet rs = stmt.executeQuery()) {
				while(rs.next()) {
					int id = rs.getInt("id");
					String name = rs.getString("name");
					double price = rs.getDouble("price");
					Timestamp ordDate = rs.getTimestamp("order_dt");
					String status = rs.getString("status");
					System.out.println(id + ", " + name + ", " + price + ", " + ordDate + ", " + status);
				}
			} 
		} 
	} 
	}
	public static void main(String[] args) throws SQLException {
		// TODO Auto-generated method stub
		while(true)
		{
			System.out.println("1.SignUp");
			System.out.println("2.SignIn");
			System.out.println("3.SignOut");
			System.out.println("4.addProduct");
			System.out.println("5.updateProduct");
			System.out.println("6.deleteProduct");
			System.out.println("7.displayallProduct");
			System.out.println("8. placeOrder");
			System.out.println("9.changeorderstatus");
			System.out.println("10.find product by name");
			System.out.println("11.showCustmoerOrder");
			System.out.println("0.Exit");
			System.out.println("Enter your choice:");
			int choice=sc.nextInt();
			
			switch(choice)
			{
			case 1:
				SignUp();
				break;
			case 2:
				signIn();
				break;
			case 3:
				signOut();
				break;
			case 4:
				addProduct();
				break;
			case 5:
				updateProduct();
				break;
			case 6:
				deleteProduct();
				break;
			case 7:
				displayallProduct();
				break;
			case 8:
				placeOrder();
				break;
			case 9:
				changeOrderStatus();
				break;
			case 10:
				showCustmoerOrder();
				break;
			case 11:
				findProduct() ;
				break;
			default:
				System.out.println("Invalid choice!!");
				break;
			}
		}
	}

}

package com.dkte;

import java.util.Scanner;

public class Student implements Comparable<Student> {
	int rollno;
	String name;
	double marks;
	
	public Student()
	{
		
	}
	public Student(int rollno,String name,double marks)
	{
		this.rollno=rollno;
		this.name=name;
		this.marks=marks;
	}
	public Student accept(Scanner sc)
	{
		System.out.println("Enter rollno:");
		rollno=sc.nextInt();
		System.out.println("Enter name:");
		name=sc.next();
		System.out.println("Enter marks:");
		marks=sc.nextDouble();
		Student stu=new Student(rollno,name,marks);
		return stu;
	}
	public double getMarks() {
		return marks;
	}
	public String getName() {
		return name;
	}
	
	
	public int getRollno() {
		return rollno;
	}
	
	@Override
	public String toString() {
		return "Student [rollno=" + rollno + ", name=" + name + ", marks=" + marks + "]";
	}
	@Override
	public int compareTo(Student o) {
		// TODO Auto-generated method stub
		return this.rollno-o.rollno;
	}
	
	

}

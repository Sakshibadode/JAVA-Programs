package com.dkte;

import java.util.ArrayList;
import java.util.Collections;

import java.util.List;
import java.util.Scanner;

public class StudentTest {
	public static int menu(Scanner sc)
	{
		System.out.println("0.Exit");
		System.out.println("1.Add Student:");
		System.out.println("2.display all Students");
		System.out.println("3.display students on rollno");
		System.out.println("4.display students on name");
		System.out.println("5.display students on marks");
		System.out.println("6.display students on marks(Descending order)");
		System.out.println("7.search the student on rollno and if found display his details.");
		System.out.println("Enter your choice:=");
		return sc.nextInt();
	}

	public static void main(String[] args) {
		Scanner sc=new Scanner(System.in);
		Student st=new Student();
		List<Student> slist=new ArrayList<>();
		
		System.out.println("size:"+slist.size());
		int choice;
		while((choice=menu(sc))!=0)
		{
			switch(choice)
			{
			case 1:
				slist.add(st.accept(sc));
				break;
			case 2:
				slist.forEach(s->System.out.println(s));
				slist.toString();
				break;
			
			case 3:
				Collections.sort(slist);
				slist.forEach(s->System.out.println(s));
				break;
			case 4:
				slist.sort((e1,e2)->e1.getName().compareTo(e2.getName()));
				slist.forEach(s->System.out.println(s));
				break;
			case 5:
				slist.sort((e1,e2)->Double.compare(e1.getMarks(), e2.getMarks()));
				slist.forEach(s->System.out.println(s));
				break;
			case 6:
				slist.sort((e1,e2)->Double.compare(e2.getMarks(),e1.getMarks()));
				slist.forEach(s->System.out.println(s));
				break;
			case 7:
				System.out.println("Enter rollno search the student on roll:");
				double roll=sc.nextDouble();
				boolean found=false;
				for(Student r:slist)
					if(r!=null && st.getRollno()==roll)
					{
						System.out.println("Student found"+r);
						found=true;
					}
				if(!found)
				{
					System.out.println("Student not found!!!");
				}
				break;
			default:
				System.out.println("Invalid choice!!!!");
				break;
			}
		}
		

	}

	
}

package com.dkte;

public class Student {
	String name;
	int rollno;
	double marks;
	
	public Student()
	{
		
	}
	
	public Student(String name,int rollno,double marks)
	{
		this.name=name;
		this.rollno=rollno;
		this.marks=marks;
	}
	
	public void displayStud()
	{
		System.out.println("Student info!!!!!");
		System.out.println("name:="+name);
		System.out.println("rollno:="+rollno);
		System.out.println("marks:="+marks);
		
	}

}

package com.dkte;

public class Program {


	public static void main(String[] args) {
		
		Student[][] studentlist=new Student[2][];
		studentlist[0]=new Student[3];
		studentlist[1]=new Student[2];
		studentlist[0][0]=new Student("nita",10,50.0);
		studentlist[0][1]=new Student("sita",20,60.0);
		studentlist[0][2]=new Student("gita",30,70.0);
		studentlist[1][0]=new Student("hita",40,80.0);
		studentlist[1][1]=new Student("rita",50,90.0);
		
		
		
		for(int i=0;i<=studentlist.length;i++)
			studentlist[0][i].displayStud();
		
		for(int j=0;j<=studentlist.length;j++)
			studentlist[1][j].displayStud();
		
		        
		       
				
		
		

	}

}

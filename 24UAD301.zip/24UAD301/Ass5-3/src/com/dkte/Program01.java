package com.dkte;

import java.util.Scanner;

public class Program01 {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		Scanner sc=new Scanner(System.in);
		System.out.println("Enter String:=");
		String s1=sc.next();
		String reverse="";
		for(int i=s1.length()-1;i>=0;i--)
		{
			reverse +=s1.charAt(i);
		}	
		if(s1.equals(reverse))
		{
			System.out.println("String is pallindrome!!!");
		}
		else
		{
			System.out.println("String is not pallindrome");
		}
	}

}

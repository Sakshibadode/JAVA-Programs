package com.dkte;

import java.util.Scanner;

public class Program01 {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		Scanner sc=new Scanner(System.in);
		Employee e=null;
		System.out.println("press 1 for Employee");
		System.out.println("press 2 for Manager");
		System.out.println("press 3 for Salesman");
		System.out.println("Enter your choice:=");
		int choice=sc.nextInt();
		switch(choice)
		{
		case 1:                          //upcasting
			e=new Employee();
			break;
		case 2:
			e=new Manager();
			break;
		case 3:
			e=new Salesman();
			break;
		}
		e.accept(sc);
		e.display();
		
		if(e instanceof Salesman)              //downcasting
		{
			Salesman s= (Salesman) e;
			s.calculate_totalcommission();
			
		}
		

	}

}

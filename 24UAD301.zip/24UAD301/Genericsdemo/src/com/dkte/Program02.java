package com.dkte;
class Pen<Y>
{
	private Y obj;
	
	public Pen(Y obj)
	{
		this.obj=obj;
	}

	public Y getObj() {
		return obj;
	}

	public void setObj(Y obj) {
		this.obj = obj;
	}
	
}

public class Program02 {
	public static void display(Pen<? extends Number> p)      //Upper Bound  ...it can take only Number class and its subclass
	{
		System.out.println("value:="+p.getObj());
	}

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		Pen<Integer> p1=new Pen<Integer>(10);
		display(p1);
		Pen<Double> p2=new Pen<Double>(10.0);
		display(p2);
		Pen<Number> p3=new Pen<Number>(100);
		display(p3);
		
		

	}

}

package com.dkte;

class List<T>
{
	private T obj;
	
	public List(T obj)
	{
		this.obj=obj;
	}

	public T getObj() {
		return obj;
	}

	public void setObj(T obj) {
		this.obj = obj;
	}
	
}

public class Program01 {
	
	private static void display(List<?> b)                 	//Unbounded type parameter
	{
		System.out.println("value:="+b.getObj());
	}
	

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		List<Integer> b1=new List<Integer>(10);
		display(b1);
		List<String> s1=new List<String>("Sakshi");
		display(s1);
		List<Double> d1=new List<Double>(10.0);
		display(d1);
		

	}

}

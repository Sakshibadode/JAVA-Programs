package com.dkte;

//Bounded type parameter
class Box<T extends Number>
{
	private T obj;

	public T getObj() {
		return obj;
	}

	public void setObj(T obj) {
		this.obj = obj;
	}
	
}

public class Program {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		Box<Integer> b=new Box<Integer>();        //ok
		b.setObj(10);
		Integer i1=b.getObj();
		System.out.println("Integer:="+i1);
		
	//	Box<Date> d=new Box<Date>();
		
		Box<Double> b1=new Box<Double>();      //ok  syntax
		b1.setObj(10.0);
		
		Box<Number> b2=new Box<Number>();     //ok syntax
		

	}

}

package com.dkte;

class Book<T>
{
	private T obj;
	public Book(T obj)
	{
		this.obj=obj;
	}
	public T getObj() {
		return obj;
	}
	public void setObj(T obj) {
		this.obj = obj;
	}
	
}

public class Program03 {
	public static void display(Book<? super Integer> b)
	{
		System.out.println("value:="+b.getObj());
	}

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		Book<Number> b1=new Book<Number>(100);
		display(b1);
		Book<Integer> b2=new Book<Integer>(10);
		display(b2);
	}

}

package com.dkte;

public class Circle {
	static double PI=3.14;
	int radius;
	public void calculate(int radius)
	{
		this.radius=radius;
	}
	public void calulate_area(int radius)
	{
		double result=PI*radius*radius;
		System.out.println("circle area:="+result);
	}
	
}

package com.dkte;

public class program {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		Circle c=new Circle();
		c.calulate_area(4);

	}

}

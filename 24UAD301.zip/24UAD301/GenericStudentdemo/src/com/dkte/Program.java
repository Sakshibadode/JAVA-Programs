package com.dkte;

import java.util.Arrays;

class Student implements Comparable<Student>
{
	int rollno;
	String name;
	double marks;
	
	public Student()
	{
		
	}
	public Student(int rollno,String name,double marks)
	{
		this.rollno=rollno;
		this.name=name;
		this.marks=marks;
	}
	@Override
	public String toString() {
		return "Student [rollno=" + rollno + ", name=" + name + ", marks=" + marks + "]";
	}
	/*@Override
	public int compareTo(Student o) {
		// TODO Auto-generated method stub
		return this.rollno-o.rollno;
	}
	*/
	/*@Override
	public int compareTo(Student o) {
		// TODO Auto-generated method stub
		return this.name.compareTo(o.name);
	}
	*/
	@Override
	public int compareTo(Student o) {
		// TODO Auto-generated method stub
		return Double.compare(this.marks, o.marks);
	}
	
	
	
}

public class Program {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		Student arr[]=new Student[3];
		arr[0]=new Student(20,"arya",80.0);
		arr[1]=new Student(40,"trupti",50.0);
		arr[2]=new Student(10,"shweta",90.0);
		System.out.println("Before Sorting:");
		for(Student s:arr)
			System.out.println("Students:"+s);
		
		Arrays.sort(arr);
		
		System.out.println("After Sorting:");
		for(Student s:arr)
			System.out.println("Students:"+s);

	}

}

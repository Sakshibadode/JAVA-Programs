package com.dke;
import java.util.InputMismatchException;
import java.util.Scanner;

public class Demo {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		Scanner sc = new Scanner(System.in);

        System.out.println("Enter the first number (double):");
        if (!sc.hasNextDouble() || sc.hasNextInt()) {
            System.out.println("Invalid input! Only double values (e.g. 5.5, 3.14) are allowed.");
            sc.close();
            return;
        }
        double n1 = sc.nextDouble();

        System.out.println("Enter the second number (double):");
        if (!sc.hasNextDouble() || sc.hasNextInt()) {
            System.out.println("Invalid input! Only double values (e.g. 5.5, 3.14) are allowed.");
            sc.close();
            return;
        }
        double n2 = sc.nextDouble();

        double average = (n1 + n2) / 2;
        System.out.println("Average: " + average);

        sc.close();
    }
}